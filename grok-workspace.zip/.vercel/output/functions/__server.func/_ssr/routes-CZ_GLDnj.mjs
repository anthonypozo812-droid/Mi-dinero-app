import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ChevronLeft, i as ChevronRight, r as Trash2, t as X } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CZ_GLDnj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm text-sm font-medium transition-opacity duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink/30 disabled:pointer-events-none disabled:opacity-40 active:opacity-80", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "border border-line bg-paper text-ink hover:bg-canvas",
			ghost: "bg-transparent text-ink hover:bg-track",
			danger: "border border-danger/30 bg-paper text-danger hover:bg-canvas"
		},
		size: {
			default: "min-h-11 px-4",
			icon: "size-11 p-0"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "default"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-sm border border-line bg-paper px-3 text-base text-ink placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink/30", className),
		...props
	});
}
function Field({ label, hint, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-2 block text-sm text-danger",
				role: "alert",
				children: error
			}) : hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-2 block text-sm text-muted",
				children: hint
			}) : null
		]
	});
}
function Modal({ open, onOpenChange, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "modal-overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "modal-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "font-display text-2xl tracking-tight",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-2 text-sm text-muted",
						children: description
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "inline-flex size-11 shrink-0 items-center justify-center rounded-sm text-muted hover:bg-canvas hover:text-ink",
					"aria-label": "Cerrar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
						className: "size-4",
						"aria-hidden": "true"
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children
			})]
		})] })
	});
}
function monthKeyFromDate(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}
function todayISO(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function shiftMonth(monthKey, delta) {
	const [year, month] = monthKey.split("-").map(Number);
	return monthKeyFromDate(new Date(year, month - 1 + delta, 1));
}
function monthBounds(monthKey) {
	const [year, month] = monthKey.split("-").map(Number);
	const last = new Date(year, month, 0).getDate();
	return {
		min: `${monthKey}-01`,
		max: `${monthKey}-${String(last).padStart(2, "0")}`
	};
}
function defaultDateFor(monthKey, today = /* @__PURE__ */ new Date()) {
	const current = monthKeyFromDate(today);
	const bounds = monthBounds(monthKey);
	if (monthKey === current) return todayISO(today);
	if (monthKey < current) return bounds.max;
	return bounds.min;
}
function monthLabel(monthKey) {
	const [year, month] = monthKey.split("-").map(Number);
	const formatted = new Intl.DateTimeFormat("es", {
		month: "long",
		year: "numeric"
	}).format(new Date(year, month - 1, 1));
	return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}
function formatDay(isoDate) {
	const [year, month, day] = isoDate.split("-").map(Number);
	return new Intl.DateTimeFormat("es", {
		day: "numeric",
		month: "short"
	}).format(new Date(year, month - 1, day));
}
function formatStamp(iso) {
	return new Intl.DateTimeFormat("es", {
		day: "numeric",
		month: "short",
		year: "numeric"
	}).format(new Date(iso));
}
function formatMoney(cents) {
	const negative = cents < 0;
	const abs = Math.abs(cents);
	const amount = new Intl.NumberFormat("es-MX", {
		minimumFractionDigits: abs % 100 === 0 ? 0 : 2,
		maximumFractionDigits: 2
	}).format(abs / 100);
	return `${negative ? "−" : ""}$${amount}`;
}
function centsToInput(cents) {
	if (cents % 100 === 0) return String(cents / 100);
	return (cents / 100).toFixed(2);
}
function parseAmountToCents(raw) {
	const trimmed = raw.trim().replace(/\s/g, "").replace(/\$/g, "");
	if (!trimmed) return null;
	let normalized = trimmed;
	if (trimmed.includes(",") && trimmed.includes(".")) {
		if (trimmed.lastIndexOf(",") > trimmed.lastIndexOf(".")) normalized = trimmed.replace(/\./g, "").replace(",", ".");
		else normalized = trimmed.replace(/,/g, "");
	} else if (trimmed.includes(",")) normalized = trimmed.replace(",", ".");
	if (!/^\d+(\.\d{1,2})?$/.test(normalized)) return null;
	const value = Number(normalized);
	if (!Number.isFinite(value) || value < 0) return null;
	const cents = Math.round(value * 100);
	if (cents > 1e9) return null;
	return cents;
}
var emptyData = {
	envelopes: [],
	allocations: [],
	transactions: [],
	savings: [],
	closedMonths: []
};
var MONTH = /^\d{4}-\d{2}$/;
var DAY = /^\d{4}-\d{2}-\d{2}$/;
function incomeCents(data, monthKey) {
	return data.transactions.reduce((sum, tx) => {
		if (tx.kind === "income" && tx.monthKey === monthKey) return sum + tx.amountCents;
		return sum;
	}, 0);
}
function spentCents(data, monthKey, envelopeId) {
	return data.transactions.reduce((sum, tx) => {
		if (tx.kind !== "expense" || tx.monthKey !== monthKey) return sum;
		if (envelopeId && tx.envelopeId !== envelopeId) return sum;
		return sum + tx.amountCents;
	}, 0);
}
function explicitAllocation(data, monthKey, envelopeId) {
	return data.allocations.find((item) => item.envelopeId === envelopeId && item.monthKey === monthKey);
}
function effectiveAllocation(data, monthKey, envelopeId) {
	const exact = explicitAllocation(data, monthKey, envelopeId);
	if (exact) return exact.amountCents;
	const envelope = data.envelopes.find((item) => item.id === envelopeId);
	if (!envelope || envelope.archived) return 0;
	return data.allocations.filter((item) => item.envelopeId === envelopeId && item.monthKey < monthKey).sort((a, b) => a.monthKey < b.monthKey ? 1 : -1)[0]?.amountCents ?? 0;
}
function allocationOrigin(data, monthKey, envelopeId) {
	if (explicitAllocation(data, monthKey, envelopeId)) return "explicit";
	const envelope = data.envelopes.find((item) => item.id === envelopeId);
	if (!envelope || envelope.archived) return "none";
	return data.allocations.some((item) => item.envelopeId === envelopeId && item.monthKey < monthKey) ? "carried" : "none";
}
function monthEnvelopes(data, monthKey) {
	const closed = data.closedMonths.includes(monthKey);
	return data.envelopes.filter((envelope) => {
		const explicit = Boolean(explicitAllocation(data, monthKey, envelope.id));
		const spent = spentCents(data, monthKey, envelope.id) > 0;
		if (closed) return explicit || spent;
		if (!envelope.archived) return true;
		return explicit || spent;
	}).sort((a, b) => a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0);
}
function envelopeLeftCents(data, monthKey, envelopeId) {
	return effectiveAllocation(data, monthKey, envelopeId) - spentCents(data, monthKey, envelopeId);
}
function assignedCents(data, monthKey) {
	return monthEnvelopes(data, monthKey).reduce((sum, envelope) => sum + effectiveAllocation(data, monthKey, envelope.id), 0);
}
function unassignedCents(data, monthKey) {
	return incomeCents(data, monthKey) - assignedCents(data, monthKey);
}
function savingsBalance(data) {
	return data.savings.reduce((sum, move) => sum + move.amountCents, 0);
}
function envelopeHasExpenses(data, envelopeId) {
	return data.transactions.some((tx) => tx.envelopeId === envelopeId);
}
function closePreview(data, monthKey, includeUnassigned) {
	const lines = monthEnvelopes(data, monthKey).map((envelope) => {
		const allocated = effectiveAllocation(data, monthKey, envelope.id);
		const spent = spentCents(data, monthKey, envelope.id);
		const left = allocated - spent;
		return {
			envelopeId: envelope.id,
			name: envelope.name,
			allocatedCents: allocated,
			spentCents: spent,
			leftCents: left,
			toSavingsCents: Math.max(0, left)
		};
	});
	const envelopeSavingsCents = lines.reduce((sum, line) => sum + line.toSavingsCents, 0);
	const unassigned = unassignedCents(data, monthKey);
	const unassignedToSavingsCents = includeUnassigned ? Math.max(0, unassigned) : 0;
	const note = includeUnassigned && unassignedToSavingsCents > 0 ? `Cierre de ${monthLabel(monthKey)}: sobres y dinero sin asignar` : `Cierre de ${monthLabel(monthKey)}`;
	return {
		lines,
		unassignedCents: unassigned,
		unassignedToSavingsCents,
		envelopeSavingsCents,
		totalCents: envelopeSavingsCents + unassignedToSavingsCents,
		note
	};
}
function fail(error) {
	return {
		ok: false,
		error
	};
}
function addTransaction(data, input) {
	if (!DAY.test(input.date)) return fail("Fecha inválida.");
	const monthKey = input.date.slice(0, 7);
	if (data.closedMonths.includes(monthKey)) return fail("Ese mes está cerrado.");
	if (!Number.isInteger(input.amountCents) || input.amountCents <= 0 || input.amountCents > 1e9) return fail("Escribe un monto mayor a cero.");
	let envelopeId = null;
	if (input.kind === "expense") {
		const envelope = data.envelopes.find((item) => item.id === input.envelopeId);
		if (!envelope) return fail("Elige un sobre.");
		envelopeId = envelope.id;
	}
	const tx = {
		id: input.id,
		kind: input.kind,
		envelopeId,
		amountCents: input.amountCents,
		note: input.note.trim().slice(0, 80),
		date: input.date,
		monthKey,
		createdAt: input.now
	};
	return {
		ok: true,
		data: {
			...data,
			transactions: [...data.transactions, tx]
		}
	};
}
function removeTransaction(data, id) {
	const tx = data.transactions.find((item) => item.id === id);
	if (!tx) return fail("No se encontró el movimiento.");
	if (data.closedMonths.includes(tx.monthKey)) return fail("Ese mes está cerrado.");
	return {
		ok: true,
		data: {
			...data,
			transactions: data.transactions.filter((item) => item.id !== id)
		}
	};
}
function saveEnvelope(data, input) {
	const name = input.name.trim();
	if (name.length < 1 || name.length > 40) return fail("El nombre necesita entre 1 y 40 caracteres.");
	if (!MONTH.test(input.monthKey)) return fail("Mes inválido.");
	if (data.closedMonths.includes(input.monthKey)) return fail("Ese mes está cerrado.");
	if (!Number.isInteger(input.amountCents) || input.amountCents < 0 || input.amountCents > 1e9) return fail("Revisa el monto destinado.");
	if (!input.id && input.amountCents <= 0) return fail("Destina un monto mayor a cero.");
	if (data.envelopes.some((envelope) => !envelope.archived && envelope.id !== input.id && envelope.name.toLocaleLowerCase("es") === name.toLocaleLowerCase("es"))) return fail("Ya tienes un sobre con ese nombre.");
	if (!input.id) {
		const envelope = {
			id: input.idIfNew,
			name,
			archived: false,
			createdAt: input.now
		};
		return {
			ok: true,
			data: {
				...data,
				envelopes: [...data.envelopes, envelope],
				allocations: [...data.allocations, {
					envelopeId: envelope.id,
					monthKey: input.monthKey,
					amountCents: input.amountCents
				}]
			}
		};
	}
	if (!data.envelopes.some((envelope) => envelope.id === input.id)) return fail("No se encontró el sobre.");
	return {
		ok: true,
		data: {
			...data,
			envelopes: data.envelopes.map((envelope) => envelope.id === input.id ? {
				...envelope,
				name
			} : envelope),
			allocations: [...data.allocations.filter((item) => !(item.envelopeId === input.id && item.monthKey === input.monthKey)), {
				envelopeId: input.id,
				monthKey: input.monthKey,
				amountCents: input.amountCents
			}]
		}
	};
}
function setArchived(data, id, archived) {
	if (!data.envelopes.some((envelope) => envelope.id === id)) return fail("No se encontró el sobre.");
	return {
		ok: true,
		data: {
			...data,
			envelopes: data.envelopes.map((envelope) => envelope.id === id ? {
				...envelope,
				archived
			} : envelope)
		}
	};
}
function deleteEnvelope(data, id) {
	if (!data.envelopes.some((envelope) => envelope.id === id)) return fail("No se encontró el sobre.");
	if (envelopeHasExpenses(data, id)) return fail("Este sobre ya tiene gastos. Archívalo para ocultarlo sin perder el historial.");
	return {
		ok: true,
		data: {
			...data,
			envelopes: data.envelopes.filter((envelope) => envelope.id !== id),
			allocations: data.allocations.filter((item) => item.envelopeId !== id)
		}
	};
}
function applyClose(data, monthKey, includeUnassigned, now, id) {
	if (!MONTH.test(monthKey)) return fail("Mes inválido.");
	if (data.closedMonths.includes(monthKey)) return fail("Ese mes ya está cerrado.");
	const preview = closePreview(data, monthKey, includeUnassigned);
	const materialized = data.envelopes.filter((envelope) => !envelope.archived).map((envelope) => ({
		envelopeId: envelope.id,
		monthKey,
		amountCents: effectiveAllocation(data, monthKey, envelope.id)
	}));
	const savings = preview.totalCents > 0 ? [...data.savings, {
		id,
		amountCents: preview.totalCents,
		note: preview.note,
		monthKey,
		source: "close",
		createdAt: now
	}] : data.savings;
	return {
		ok: true,
		data: {
			...data,
			allocations: [...data.allocations.filter((item) => item.monthKey !== monthKey), ...materialized],
			savings,
			closedMonths: [...data.closedMonths, monthKey]
		}
	};
}
function applyReopen(data, monthKey) {
	if (!data.closedMonths.includes(monthKey)) return fail("Ese mes no está cerrado.");
	return {
		ok: true,
		data: {
			...data,
			closedMonths: data.closedMonths.filter((item) => item !== monthKey),
			savings: data.savings.filter((item) => !(item.source === "close" && item.monthKey === monthKey))
		}
	};
}
function addSavings(data, input) {
	if (!Number.isInteger(input.amountCents) || input.amountCents === 0) return fail("Escribe un monto mayor a cero.");
	if (Math.abs(input.amountCents) > 1e9) return fail("Ese monto es demasiado alto.");
	if (savingsBalance(data) + input.amountCents < 0) return fail("No puedes retirar más de lo ahorrado.");
	const move = {
		id: input.id,
		amountCents: input.amountCents,
		note: input.note.trim().slice(0, 80) || (input.amountCents > 0 ? "Apartado manual" : "Retiro"),
		monthKey: null,
		source: "manual",
		createdAt: input.now
	};
	return {
		ok: true,
		data: {
			...data,
			savings: [...data.savings, move]
		}
	};
}
function isRecord(value) {
	return typeof value === "object" && value !== null;
}
function isCents(value, allowNegative) {
	return typeof value === "number" && Number.isInteger(value) && value <= 1e9 && (allowNegative ? value >= -1e9 : value >= 0);
}
function parseBackup(raw) {
	if (!isRecord(raw)) return null;
	const payload = raw.app === "sobres" && isRecord(raw.data) ? raw.data : raw;
	if (!isRecord(payload)) return null;
	if (!Array.isArray(payload.envelopes) || !Array.isArray(payload.allocations) || !Array.isArray(payload.transactions) || !Array.isArray(payload.savings) || !Array.isArray(payload.closedMonths)) return null;
	if (payload.envelopes.length > 5e3 || payload.allocations.length > 5e3 || payload.transactions.length > 5e3 || payload.savings.length > 5e3 || payload.closedMonths.length > 5e3) return null;
	const envelopes = [];
	const envelopeIds = /* @__PURE__ */ new Set();
	for (const item of payload.envelopes) {
		if (!isRecord(item)) return null;
		if (typeof item.id !== "string" || item.id.length < 1 || item.id.length > 80) return null;
		if (typeof item.name !== "string" || item.name.trim().length < 1 || item.name.length > 40) return null;
		if (typeof item.archived !== "boolean") return null;
		if (typeof item.createdAt !== "string" || item.createdAt.length > 40) return null;
		if (envelopeIds.has(item.id)) return null;
		envelopeIds.add(item.id);
		envelopes.push({
			id: item.id,
			name: item.name.trim(),
			archived: item.archived,
			createdAt: item.createdAt
		});
	}
	const allocations = [];
	const allocationKeys = /* @__PURE__ */ new Set();
	for (const item of payload.allocations) {
		if (!isRecord(item)) return null;
		if (typeof item.envelopeId !== "string" || !envelopeIds.has(item.envelopeId)) return null;
		if (typeof item.monthKey !== "string" || !MONTH.test(item.monthKey)) return null;
		if (!isCents(item.amountCents, false)) return null;
		const key = `${item.envelopeId}:${item.monthKey}`;
		if (allocationKeys.has(key)) return null;
		allocationKeys.add(key);
		allocations.push({
			envelopeId: item.envelopeId,
			monthKey: item.monthKey,
			amountCents: item.amountCents
		});
	}
	const transactions = [];
	const txIds = /* @__PURE__ */ new Set();
	for (const item of payload.transactions) {
		if (!isRecord(item)) return null;
		if (typeof item.id !== "string" || item.id.length < 1 || item.id.length > 80) return null;
		if (item.kind !== "income" && item.kind !== "expense") return null;
		if (typeof item.date !== "string" || !DAY.test(item.date)) return null;
		if (typeof item.monthKey !== "string" || item.monthKey !== item.date.slice(0, 7)) return null;
		if (!isCents(item.amountCents, false) || item.amountCents === 0) return null;
		if (typeof item.note !== "string" || item.note.length > 80) return null;
		if (typeof item.createdAt !== "string" || item.createdAt.length > 40) return null;
		if (txIds.has(item.id)) return null;
		let envelopeId = null;
		if (item.kind === "expense") {
			if (typeof item.envelopeId !== "string" || !envelopeIds.has(item.envelopeId)) return null;
			envelopeId = item.envelopeId;
		} else if (item.envelopeId !== null && item.envelopeId !== void 0) return null;
		txIds.add(item.id);
		transactions.push({
			id: item.id,
			kind: item.kind,
			envelopeId,
			amountCents: item.amountCents,
			note: item.note,
			date: item.date,
			monthKey: item.monthKey,
			createdAt: item.createdAt
		});
	}
	const savings = [];
	const savingsIds = /* @__PURE__ */ new Set();
	for (const item of payload.savings) {
		if (!isRecord(item)) return null;
		if (typeof item.id !== "string" || item.id.length < 1 || item.id.length > 80) return null;
		if (!isCents(item.amountCents, true) || item.amountCents === 0) return null;
		if (typeof item.note !== "string" || item.note.length > 120) return null;
		if (item.source !== "close" && item.source !== "manual") return null;
		if (!(item.monthKey === null || typeof item.monthKey === "string" && MONTH.test(item.monthKey))) return null;
		if (typeof item.createdAt !== "string" || item.createdAt.length > 40) return null;
		if (savingsIds.has(item.id)) return null;
		savingsIds.add(item.id);
		savings.push({
			id: item.id,
			amountCents: item.amountCents,
			note: item.note,
			monthKey: item.monthKey,
			source: item.source,
			createdAt: item.createdAt
		});
	}
	const closedMonths = [];
	const seenMonths = /* @__PURE__ */ new Set();
	for (const item of payload.closedMonths) {
		if (typeof item !== "string" || !MONTH.test(item) || seenMonths.has(item)) return null;
		seenMonths.add(item);
		closedMonths.push(item);
	}
	return {
		envelopes,
		allocations,
		transactions,
		savings,
		closedMonths
	};
}
function serializeBackup(data) {
	return JSON.stringify({
		app: "sobres",
		version: 1,
		data
	}, null, 2);
}
function snapshot(state) {
	return {
		envelopes: state.envelopes,
		allocations: state.allocations,
		transactions: state.transactions,
		savings: state.savings,
		closedMonths: state.closedMonths
	};
}
function stamp() {
	return {
		id: crypto.randomUUID(),
		now: (/* @__PURE__ */ new Date()).toISOString()
	};
}
var useBudget = create()(persist((set, get) => {
	const commit = (result) => {
		if (!result.ok) return result.error;
		set(result.data);
		return null;
	};
	return {
		...emptyData,
		addIncome: (input) => {
			const { id, now } = stamp();
			return commit(addTransaction(snapshot(get()), {
				kind: "income",
				amountCents: input.amountCents,
				note: input.note,
				date: input.date,
				id,
				now
			}));
		},
		addExpense: (input) => {
			const { id, now } = stamp();
			return commit(addTransaction(snapshot(get()), {
				kind: "expense",
				envelopeId: input.envelopeId,
				amountCents: input.amountCents,
				note: input.note,
				date: input.date,
				id,
				now
			}));
		},
		removeTransaction: (id) => commit(removeTransaction(snapshot(get()), id)),
		saveEnvelope: (input) => {
			const { id, now } = stamp();
			return commit(saveEnvelope(snapshot(get()), {
				...input,
				idIfNew: id,
				now
			}));
		},
		setArchived: (id, archived) => commit(setArchived(snapshot(get()), id, archived)),
		deleteEnvelope: (id) => commit(deleteEnvelope(snapshot(get()), id)),
		closeMonth: (monthKey, includeUnassigned) => {
			const { id, now } = stamp();
			return commit(applyClose(snapshot(get()), monthKey, includeUnassigned, now, id));
		},
		reopenMonth: (monthKey) => commit(applyReopen(snapshot(get()), monthKey)),
		moveSavings: (amountCents, note) => {
			const { id, now } = stamp();
			return commit(addSavings(snapshot(get()), {
				amountCents,
				note,
				id,
				now
			}));
		},
		importBackup: (raw) => {
			const data = parseBackup(raw);
			if (!data) return "Ese archivo no es una copia de Sobres.";
			set(data);
			return null;
		},
		reset: () => set(emptyData)
	};
}, {
	name: "sobres.v1",
	version: 1,
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? {
		getItem: () => null,
		setItem: () => void 0,
		removeItem: () => void 0
	} : localStorage),
	partialize: (state) => ({
		envelopes: state.envelopes,
		allocations: state.allocations,
		transactions: state.transactions,
		savings: state.savings,
		closedMonths: state.closedMonths
	})
}));
var SUGGESTIONS = [
	"Alimentación",
	"Transporte",
	"Casa",
	"Servicios",
	"Salud",
	"Personal"
];
function BudgetDialogs({ request, monthKey, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncomeDialog, {
			open: request?.kind === "income",
			monthKey,
			onClose
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseDialog, {
			open: request?.kind === "expense",
			envelopeId: request?.kind === "expense" ? request.envelopeId : null,
			monthKey,
			onClose
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnvelopeDialog, {
			open: request?.kind === "envelope",
			envelopeId: request?.kind === "envelope" ? request.envelopeId : void 0,
			monthKey,
			onClose
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseDialog, {
			open: request?.kind === "close",
			monthKey,
			onClose
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReopenDialog, {
			open: request?.kind === "reopen",
			monthKey,
			onClose
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteTxDialog, {
			open: request?.kind === "delete-tx",
			id: request?.kind === "delete-tx" ? request.id : null,
			onClose
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SavingsDialog, {
			open: request?.kind === "savings-in" || request?.kind === "savings-out",
			mode: request?.kind === "savings-out" ? "out" : "in",
			onClose
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResetDialog, {
			open: request?.kind === "reset",
			onClose
		})
	] });
}
function IncomeDialog({ open, monthKey, onClose }) {
	const addIncome = useBudget((state) => state.addIncome);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(defaultDateFor(monthKey));
	const [error, setError] = (0, import_react.useState)(null);
	const bounds = monthBounds(monthKey);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setAmount("");
		setNote("");
		setDate(defaultDateFor(monthKey));
		setError(null);
	}, [open, monthKey]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: "Registrar ingreso",
		description: "Es el dinero que entra este mes, antes de repartirlo en sobres.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				const cents = parseAmountToCents(amount);
				if (cents == null || cents <= 0) {
					setError("Escribe un monto mayor a cero.");
					return;
				}
				const message = addIncome({
					amountCents: cents,
					note,
					date
				});
				if (message) {
					setError(message);
					return;
				}
				onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Monto",
					error,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						inputMode: "decimal",
						autoComplete: "off",
						placeholder: "1200",
						value: amount,
						onChange: (event) => {
							setAmount(event.target.value);
							setError(null);
						},
						autoFocus: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nota",
					hint: "Opcional. Por ejemplo, nómina o venta.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: note,
						maxLength: 80,
						placeholder: "Nómina",
						onChange: (event) => setNote(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Fecha",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						required: true,
						min: bounds.min,
						max: bounds.max,
						value: date,
						onChange: (event) => setDate(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: onClose,
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Guardar ingreso"
					})]
				})
			]
		})
	});
}
function ExpenseDialog({ open, envelopeId, monthKey, onClose }) {
	const data = useBudget();
	const envelope = data.envelopes.find((item) => item.id === envelopeId);
	const remaining = envelope ? envelopeLeftCents(data, monthKey, envelope.id) : 0;
	const [amount, setAmount] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(defaultDateFor(monthKey));
	const [error, setError] = (0, import_react.useState)(null);
	const bounds = monthBounds(monthKey);
	const cents = parseAmountToCents(amount);
	const hint = cents == null ? `Quedan ${formatMoney(remaining)} en este sobre.` : remaining - cents < 0 ? `Te pasarías por ${formatMoney(cents - remaining)}. Igual puedes registrarlo.` : `Quedarían ${formatMoney(remaining - cents)}.`;
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setAmount("");
		setNote("");
		setDate(defaultDateFor(monthKey));
		setError(null);
	}, [
		open,
		monthKey,
		envelopeId
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: envelope ? `Gasto en ${envelope.name}` : "Registrar gasto",
		description: "Se descuenta solo de este sobre, no del ahorro.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				if (!envelope) return;
				const parsed = parseAmountToCents(amount);
				if (parsed == null || parsed <= 0) {
					setError("Escribe un monto mayor a cero.");
					return;
				}
				const message = data.addExpense({
					envelopeId: envelope.id,
					amountCents: parsed,
					note,
					date
				});
				if (message) {
					setError(message);
					return;
				}
				onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Monto",
					hint: error ? void 0 : hint,
					error,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						inputMode: "decimal",
						autoComplete: "off",
						placeholder: "18",
						value: amount,
						onChange: (event) => {
							setAmount(event.target.value);
							setError(null);
						},
						autoFocus: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nota",
					hint: "Opcional. Por ejemplo, mercado o café.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: note,
						maxLength: 80,
						placeholder: "Mercado",
						onChange: (event) => setNote(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Fecha",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						required: true,
						min: bounds.min,
						max: bounds.max,
						value: date,
						onChange: (event) => setDate(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: onClose,
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Descontar"
					})]
				})
			]
		})
	});
}
function EnvelopeDialog({ open, envelopeId, monthKey, onClose }) {
	const data = useBudget();
	const existing = data.envelopes.find((item) => item.id === envelopeId);
	const [name, setName] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const editing = Boolean(existing);
	const taken = new Set(data.envelopes.filter((item) => !item.archived).map((item) => item.name.toLocaleLowerCase("es")));
	const ideas = SUGGESTIONS.filter((idea) => !taken.has(idea.toLocaleLowerCase("es")));
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (existing) {
			setName(existing.name);
			setAmount(centsToInput(effectiveAllocation(data, monthKey, existing.id)));
		} else {
			setName("");
			setAmount("");
		}
		setError(null);
	}, [
		open,
		envelopeId,
		monthKey
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: editing ? "Ajustar sobre" : "Nuevo sobre",
		description: editing ? `Cuánto destinas a ${existing?.name} en ${monthLabel(monthKey)}.` : "Un sobre es el dinero apartado para una cosa. Lo que no gastes se ahorra al cerrar el mes.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				const cents = parseAmountToCents(amount);
				if (cents == null || !editing && cents <= 0) {
					setError(editing ? "Revisa el monto destinado." : "Destina un monto mayor a cero.");
					return;
				}
				const message = data.saveEnvelope({
					id: existing?.id,
					name,
					amountCents: cents,
					monthKey
				});
				if (message) {
					setError(message);
					return;
				}
				onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nombre",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						maxLength: 40,
						placeholder: "Alimentación",
						onChange: (event) => {
							setName(event.target.value);
							setError(null);
						},
						autoFocus: true
					})
				}),
				!editing && ideas.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: ideas.map((idea) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-sm border border-line bg-paper px-3 text-sm hover:bg-canvas",
						onClick: () => {
							setName(idea);
							setError(null);
						},
						children: idea
					}, idea))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Destinado este mes",
					hint: editing ? "Si lo dejas igual el mes que viene, se repite solo." : "Por ejemplo, 80 para alimentación.",
					error,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						inputMode: "decimal",
						autoComplete: "off",
						placeholder: "80",
						value: amount,
						onChange: (event) => {
							setAmount(event.target.value);
							setError(null);
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between",
					children: [existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2",
						children: envelopeHasExpenses(data, existing.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => {
								const message = data.setArchived(existing.id, !existing.archived);
								if (message) {
									setError(message);
									return;
								}
								onClose();
							},
							children: existing.archived ? "Reactivar" : "Archivar"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								const message = data.deleteEnvelope(existing.id);
								if (message) {
									setError(message);
									return;
								}
								onClose();
							},
							children: "Eliminar"
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col-reverse gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: onClose,
							children: "Cancelar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: editing ? "Guardar" : "Crear sobre"
						})]
					})]
				})
			]
		})
	});
}
function CloseDialog({ open, monthKey, onClose }) {
	const data = useBudget();
	const [includeUnassigned, setIncludeUnassigned] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const preview = closePreview(data, monthKey, includeUnassigned);
	const lines = preview.lines.filter((line) => line.allocatedCents > 0 || line.spentCents > 0);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setIncludeUnassigned(false);
		setError(null);
	}, [open, monthKey]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: `Cerrar ${monthLabel(monthKey)}`,
		description: "Lo que quede en cada sobre pasa a ahorro. Después el mes queda bloqueado; puedes reabrirlo si te equivocaste.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Ningún sobre tiene dinero apartado este mes."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-line rounded-md border border-line",
					children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3 px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: line.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: line.leftCents < 0 ? `${formatMoney(line.spentCents)} gastados, ${formatMoney(-line.leftCents)} de más` : `${formatMoney(line.spentCents)} de ${formatMoney(line.allocatedCents)}`
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "shrink-0 text-sm font-medium tabular-nums",
							children: line.toSavingsCents > 0 ? formatMoney(line.toSavingsCents) : "$0"
						})]
					}, line.envelopeId))
				}),
				preview.unassignedCents > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "mt-1 size-5",
						checked: includeUnassigned,
						onChange: (event) => setIncludeUnassigned(event.target.checked)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium",
						children: "Incluir dinero sin asignar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-sm text-muted",
						children: [formatMoney(preview.unassignedCents), " entraron y no están en ningún sobre. Si no lo marcas, se quedan fuera del ahorro."]
					})] })]
				}) : null,
				preview.unassignedCents < 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-danger",
					children: [
						"Asignaste ",
						formatMoney(-preview.unassignedCents),
						" más de lo que entró. El cierre no resta eso del ahorro: solo pasa lo que realmente sobró en cada sobre."
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl tracking-tight tabular-nums",
					children: formatMoney(preview.totalCents)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "van a ahorro con este cierre."
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: onClose,
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							const message = data.closeMonth(monthKey, includeUnassigned);
							if (message) {
								setError(message);
								return;
							}
							onClose();
						},
						children: "Pasar a ahorro"
					})]
				})
			]
		})
	});
}
function ReopenDialog({ open, monthKey, onClose }) {
	const reopenMonth = useBudget((state) => state.reopenMonth);
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: `Reabrir ${monthLabel(monthKey)}`,
		description: "Vuelve a poder anotar gastos. El dinero que este cierre había pasado a ahorro se descuenta.",
		children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-danger",
			role: "alert",
			children: error
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: onClose,
				children: "Cancelar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => {
					const message = reopenMonth(monthKey);
					if (message) {
						setError(message);
						return;
					}
					onClose();
				},
				children: "Reabrir mes"
			})]
		})]
	});
}
function DeleteTxDialog({ open, id, onClose }) {
	const data = useBudget();
	const tx = data.transactions.find((item) => item.id === id);
	const [error, setError] = (0, import_react.useState)(null);
	const envelope = data.envelopes.find((item) => item.id === tx?.envelopeId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: "Eliminar movimiento",
		description: tx ? tx.kind === "income" ? `Se quita el ingreso de ${formatMoney(tx.amountCents)}.` : `Se devuelven ${formatMoney(tx.amountCents)} a ${envelope?.name ?? "el sobre"}.` : "Este movimiento ya no está.",
		children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-danger",
			role: "alert",
			children: error
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: onClose,
				children: "Cancelar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: () => {
					if (!tx) return;
					const message = data.removeTransaction(tx.id);
					if (message) {
						setError(message);
						return;
					}
					onClose();
				},
				children: "Eliminar"
			})]
		})]
	});
}
function SavingsDialog({ open, mode, onClose }) {
	const moveSavings = useBudget((state) => state.moveSavings);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setAmount("");
		setNote("");
		setError(null);
	}, [open, mode]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: mode === "in" ? "Apartar en ahorro" : "Retirar de ahorro",
		description: mode === "in" ? "Un movimiento manual, aparte de lo que llega al cerrar el mes." : "Sale de tu ahorro acumulado. No vuelve a un sobre.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				const cents = parseAmountToCents(amount);
				if (cents == null || cents <= 0) {
					setError("Escribe un monto mayor a cero.");
					return;
				}
				const message = moveSavings(mode === "in" ? cents : -cents, note);
				if (message) {
					setError(message);
					return;
				}
				onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Monto",
					error,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						inputMode: "decimal",
						autoComplete: "off",
						placeholder: "20",
						value: amount,
						onChange: (event) => {
							setAmount(event.target.value);
							setError(null);
						},
						autoFocus: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nota",
					hint: "Opcional.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: note,
						maxLength: 80,
						onChange: (event) => setNote(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: onClose,
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: mode === "in" ? "Apartar" : "Retirar"
					})]
				})
			]
		})
	});
}
function ResetDialog({ open, onClose }) {
	const reset = useBudget((state) => state.reset);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: "Borrar todo",
		description: "Se elimina la libreta de este dispositivo. No se puede deshacer.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: onClose,
				children: "Cancelar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: () => {
					reset();
					onClose();
				},
				children: "Borrar todo"
			})]
		})
	});
}
var STEPS = [
	{
		title: "Entra",
		body: "Anota el dinero del mes: sueldo, ventas o lo que haya llegado."
	},
	{
		title: "Aparta",
		body: "Destina un monto a cada sobre. Por ejemplo, $80 para alimentación."
	},
	{
		title: "Gasta y cierra",
		body: "Cada compra se descuenta de ese sobre. Al cerrar el mes, lo que sobra pasa a ahorro."
	}
];
function useBudgetReady() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let alive = true;
		const finish = () => {
			if (alive) setReady(true);
		};
		const unsubscribe = useBudget.persist.onFinishHydration(finish);
		if (useBudget.persist.hasHydrated()) finish();
		else useBudget.persist.rehydrate();
		return () => {
			alive = false;
			unsubscribe();
		};
	}, []);
	return ready;
}
function SobresApp() {
	if (!useBudgetReady()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingShell, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetScreen, {});
}
function LoadingShell() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-5xl px-4 py-8",
		"aria-busy": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "En este dispositivo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-4xl tracking-tight",
				children: "Sobres"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Abriendo tu libreta…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-8 h-40 rounded-lg border border-line bg-paper" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-28 rounded-lg border border-line bg-paper" })
		]
	});
}
function BudgetScreen() {
	const data = useBudget();
	const currentKey = monthKeyFromDate(/* @__PURE__ */ new Date());
	const [monthKey, setMonthKey] = (0, import_react.useState)(currentKey);
	const [tab, setTab] = (0, import_react.useState)("mes");
	const [dialog, setDialog] = (0, import_react.useState)(null);
	const closed = data.closedMonths.includes(monthKey);
	const closable = monthKey <= currentKey;
	const envelopes = monthEnvelopes(data, monthKey).filter((envelope) => {
		if (!closed) return true;
		return effectiveAllocation(data, monthKey, envelope.id) > 0 || spentCents(data, monthKey, envelope.id) > 0;
	});
	const income = incomeCents(data, monthKey);
	const spent = spentCents(data, monthKey);
	const loose = unassignedCents(data, monthKey);
	const saved = savingsBalance(data);
	const closeEntry = data.savings.find((item) => item.source === "close" && item.monthKey === monthKey);
	const projected = envelopes.reduce((sum, envelope) => sum + Math.max(0, envelopeLeftCents(data, monthKey, envelope.id)), 0);
	const heroAmount = closed ? closeEntry?.amountCents ?? 0 : projected;
	const started = income > 0 || envelopes.length > 0 || spent > 0 || data.transactions.some((tx) => tx.monthKey === monthKey);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-5xl px-4 py-6 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "En este dispositivo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl tracking-tight",
						children: "Sobres"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-md text-sm text-muted",
						children: "Aparta, gasta y lo que sobre se ahorra. Sin cuenta y sin internet."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthSwitcher, {
					monthKey,
					currentKey,
					onChange: setMonthKey
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "tablist",
				"aria-label": "Secciones",
				className: "mt-6 flex gap-1 rounded-md border border-line bg-paper p-1",
				children: [
					["mes", "Mes"],
					["movimientos", "Movimientos"],
					["ahorro", "Ahorro"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": tab === id,
					className: cn("min-h-11 flex-1 rounded-sm text-sm font-medium", tab === id ? "bg-accent text-accent-fg" : "text-muted hover:bg-canvas hover:text-ink"),
					onClick: () => setTab(id),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid items-start gap-6 lg:grid-cols-[20rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: cn("space-y-4 lg:sticky lg:top-4", tab !== "mes" && "hidden lg:block"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
							className: "rounded-lg border border-line bg-paper p-6",
							children: started ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: closed ? "Pasó a ahorro" : "Si cierras hoy, pasa a ahorro"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-display text-4xl tracking-tight tabular-nums",
									children: formatMoney(heroAmount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-muted",
									children: closed ? closeEntry ? closeEntry.note : "No sobró nada en los sobres." : "Es lo que queda en cada sobre, ya descontados los gastos."
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Cómo funciona"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-display text-3xl tracking-tight",
									children: "Tu mes, en sobres"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "mt-5 space-y-4",
									children: STEPS.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex size-8 shrink-0 items-center justify-center rounded-sm bg-track text-sm font-medium",
											children: index + 1
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-medium",
											children: step.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-sm text-muted",
											children: step.body
										})] })]
									}, step.title))
								})
							] })
						}),
						started ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Entró",
									value: income
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Gastado",
									value: spent
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Sin asignar",
									value: loose,
									signed: true
								})
							]
						}) : null,
						started && loose !== 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: loose > 0 ? `${formatMoney(loose)} todavía no están en un sobre. No se ahorran solos: márcalo al cerrar el mes, o apártalo.` : `Asignaste ${formatMoney(-loose)} más de lo que entró este mes.`
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2",
							children: [!closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => setDialog({ kind: "income" }),
								children: "Registrar ingreso"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => setDialog({ kind: "envelope" }),
								children: "Nuevo sobre"
							})] }) : null, closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => setDialog({ kind: "reopen" }),
								children: "Reabrir mes"
							}) : closable && started ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => setDialog({ kind: "close" }),
								children: "Cerrar mes"
							}) : !closable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Este mes todavía no llega. Puedes dejar los sobres listos."
							}) : null]
						}),
						data.savings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "min-h-11 text-left text-sm text-muted",
							onClick: () => setTab("ahorro"),
							children: [
								"Ahorro acumulado",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-ink tabular-nums",
									children: formatMoney(saved)
								})
							]
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					tab === "mes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthPanel, {
						monthKey,
						closed,
						envelopes,
						onExpense: (envelopeId) => setDialog({
							kind: "expense",
							envelopeId
						}),
						onEdit: (envelopeId) => setDialog({
							kind: "envelope",
							envelopeId
						}),
						onCreate: () => setDialog({ kind: "envelope" }),
						onNext: () => setMonthKey(shiftMonth(monthKey, 1))
					}) : null,
					tab === "movimientos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Movements, {
						monthKey,
						closed,
						onDelete: (id) => setDialog({
							kind: "delete-tx",
							id
						})
					}) : null,
					tab === "ahorro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SavingsPanel, {
						onIn: () => setDialog({ kind: "savings-in" }),
						onOut: () => setDialog({ kind: "savings-out" }),
						onReset: () => setDialog({ kind: "reset" })
					}) : null
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetDialogs, {
				request: dialog,
				monthKey,
				onClose: () => setDialog(null)
			})
		]
	});
}
function Stat({ label, value, signed = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0 rounded-md border border-line bg-paper px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: cn("mt-1 truncate text-sm font-medium tabular-nums", signed && value < 0 && "text-danger"),
			children: formatMoney(value)
		})]
	});
}
function MonthSwitcher({ monthKey, currentKey, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": "Mes anterior",
				onClick: () => onChange(shiftMonth(monthKey, -1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: "size-4",
					"aria-hidden": "true"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-36 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: monthLabel(monthKey)
				}), monthKey !== currentKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-1 min-h-11 text-sm text-muted",
					onClick: () => onChange(currentKey),
					children: "Volver a este mes"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": "Mes siguiente",
				onClick: () => onChange(shiftMonth(monthKey, 1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: "size-4",
					"aria-hidden": "true"
				})
			})
		]
	});
}
function MonthPanel({ monthKey, closed, envelopes, onExpense, onEdit, onCreate, onNext }) {
	const data = useBudget();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: "Sobres"
				}), !closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: onCreate,
					children: "Nuevo sobre"
				}) : null]
			}),
			closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-line bg-paper px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "Este mes está cerrado."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Lo que sobró ya está en ahorro. Reábrelo arriba si necesitas corregir un gasto."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "mt-2 px-0",
						onClick: onNext,
						children: ["Ir a ", monthLabel(shiftMonth(monthKey, 1))]
					})
				]
			}) : null,
			envelopes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-line bg-paper p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "Todavía no hay sobres"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Aparta un monto, por ejemplo $80 para alimentación. Cuando compres, se resta de ahí."
					}),
					!closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: onCreate,
						children: "Crear sobre"
					}) : null
				]
			}) : envelopes.map((envelope) => {
				const allocated = effectiveAllocation(data, monthKey, envelope.id);
				const spent = spentCents(data, monthKey, envelope.id);
				const left = allocated - spent;
				const ratio = allocated <= 0 ? spent > 0 ? 1 : 0 : Math.min(1, spent / allocated);
				const origin = allocationOrigin(data, monthKey, envelope.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-paper p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "truncate text-base font-medium",
										children: envelope.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-muted",
										children: [
											formatMoney(allocated),
											" destinados · ",
											formatMoney(spent),
											" gastados"
										]
									}),
									origin === "carried" && !closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-faint",
										children: "Mismo monto que el mes anterior."
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("font-display text-2xl tracking-tight tabular-nums", left < 0 && "text-danger"),
									children: formatMoney(left)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: left < 0 ? "de más" : "quedan"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "meter mt-4",
							role: "progressbar",
							"aria-valuemin": 0,
							"aria-valuemax": Math.max(allocated, 1),
							"aria-valuenow": Math.min(spent, Math.max(allocated, spent)),
							"aria-label": `Gastado en ${envelope.name}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"data-over": left < 0 ? "true" : "false",
								style: { width: `${ratio * 100}%` }
							})
						}),
						!closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-col gap-2 sm:flex-row",
							children: allocated === 0 && spent === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "sm:flex-1",
								onClick: () => onEdit(envelope.id),
								children: "Asignar monto"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "sm:flex-1",
								onClick: () => onExpense(envelope.id),
								children: "Registrar gasto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => onEdit(envelope.id),
								children: "Ajustar"
							})] })
						}) : null
					]
				}, envelope.id);
			})
		]
	});
}
function Movements({ monthKey, closed, onDelete }) {
	const transactions = useBudget((state) => state.transactions);
	const envelopes = useBudget((state) => state.envelopes);
	const rows = transactions.filter((tx) => tx.monthKey === monthKey).sort((a, b) => {
		if (a.date !== b.date) return a.date < b.date ? 1 : -1;
		return a.createdAt < b.createdAt ? 1 : -1;
	});
	if (rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-paper p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-medium",
			children: "Sin movimientos"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm text-muted",
			children: [
				"Los ingresos y los gastos de ",
				monthLabel(monthKey),
				" aparecen aquí."
			]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "text-lg font-medium",
		children: "Movimientos"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3 divide-y divide-line rounded-lg border border-line bg-paper",
		children: rows.map((tx) => {
			const name = tx.kind === "income" ? "Ingreso" : envelopes.find((envelope) => envelope.id === tx.envelopeId)?.name ?? "Gasto";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium",
							children: name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-sm text-muted",
							children: [formatDay(tx.date), tx.note ? ` · ${tx.note}` : ""]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "shrink-0 text-sm font-medium tabular-nums",
						children: [tx.kind === "income" ? "+" : "−", formatMoney(tx.amountCents)]
					}),
					!closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": `Eliminar ${name}`,
						onClick: () => onDelete(tx.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "size-4",
							"aria-hidden": "true"
						})
					}) : null
				]
			}, tx.id);
		})
	})] });
}
function SavingsPanel({ onIn, onOut, onReset }) {
	const data = useBudget();
	const balance = savingsBalance(data);
	const moves = [...data.savings].sort((a, b) => a.createdAt < b.createdAt ? 1 : -1);
	const fileRef = (0, import_react.useRef)(null);
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-line bg-paper p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Ahorro acumulado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-4xl tracking-tight tabular-nums",
						children: formatMoney(balance)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Crece cuando cierras un mes y sobra dinero en los sobres."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: onIn,
							children: "Apartar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: onOut,
							disabled: balance <= 0,
							children: "Retirar"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-medium",
				children: "Historial"
			}), moves.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Aquí verás cada cierre de mes."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-line rounded-lg border border-line bg-paper",
				children: moves.map((move) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium",
							children: move.note
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: formatStamp(move.createdAt)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "shrink-0 text-sm font-medium tabular-nums",
						children: [move.amountCents > 0 ? "+" : "−", formatMoney(Math.abs(move.amountCents))]
					})]
				}, move.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-line bg-paper p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium",
						children: "Copia en este dispositivo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Nada sale de este navegador. Descarga una copia si vas a cambiar de teléfono."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-2 sm:flex-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => {
									const blob = new Blob([serializeBackup(data)], { type: "application/json" });
									const url = URL.createObjectURL(blob);
									const link = document.createElement("a");
									link.href = url;
									link.download = "sobres-copia.json";
									document.body.appendChild(link);
									link.click();
									link.remove();
									URL.revokeObjectURL(url);
								},
								children: "Descargar copia"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => fileRef.current?.click(),
								children: "Restaurar copia"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: onReset,
								children: "Borrar todo"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						className: "sr-only",
						type: "file",
						accept: "application/json",
						onChange: (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							if (!file) return;
							const reader = new FileReader();
							reader.onload = () => {
								try {
									const parsed = JSON.parse(String(reader.result));
									const message = data.importBackup(parsed);
									setError(message);
								} catch {
									setError("No se pudo leer el archivo.");
								}
							};
							reader.readAsText(file);
						}
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-danger",
						role: "alert",
						children: error
					}) : null
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SobresApp, {});
}
//#endregion
export { Home as component };
