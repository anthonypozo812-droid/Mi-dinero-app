import { createFileRoute } from "@tanstack/react-router";
import { SobresApp } from "@/components/sobres/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SobresApp />;
}
