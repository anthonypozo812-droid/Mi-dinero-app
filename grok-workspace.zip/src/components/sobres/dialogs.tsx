import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import {
  closePreview,
  effectiveAllocation,
  envelopeHasExpenses,
  envelopeLeftCents,
} from "@/lib/budget-math";
import { useBudget } from "@/lib/budget-store";
import {
  centsToInput,
  defaultDateFor,
  formatMoney,
  monthBounds,
  monthLabel,
  parseAmountToCents,
} from "@/lib/money";

const SUGGESTIONS = ["Alimentación", "Transporte", "Casa", "Servicios", "Salud", "Personal"];

export type DialogRequest =
  | null
  | { kind: "income" }
  | { kind: "expense"; envelopeId: string }
  | { kind: "envelope"; envelopeId?: string }
  | { kind: "close" }
  | { kind: "reopen" }
  | { kind: "delete-tx"; id: string }
  | { kind: "savings-in" }
  | { kind: "savings-out" }
  | { kind: "reset" };

export function BudgetDialogs({
  request,
  monthKey,
  onClose,
}: {
  request: DialogRequest;
  monthKey: string;
  onClose: () => void;
}) {
  return (
    <>
      <IncomeDialog open={request?.kind === "income"} monthKey={monthKey} onClose={onClose} />
      <ExpenseDialog
        open={request?.kind === "expense"}
        envelopeId={request?.kind === "expense" ? request.envelopeId : null}
        monthKey={monthKey}
        onClose={onClose}
      />
      <EnvelopeDialog
        open={request?.kind === "envelope"}
        envelopeId={request?.kind === "envelope" ? request.envelopeId : undefined}
        monthKey={monthKey}
        onClose={onClose}
      />
      <CloseDialog open={request?.kind === "close"} monthKey={monthKey} onClose={onClose} />
      <ReopenDialog open={request?.kind === "reopen"} monthKey={monthKey} onClose={onClose} />
      <DeleteTxDialog
        open={request?.kind === "delete-tx"}
        id={request?.kind === "delete-tx" ? request.id : null}
        onClose={onClose}
      />
      <SavingsDialog
        open={request?.kind === "savings-in" || request?.kind === "savings-out"}
        mode={request?.kind === "savings-out" ? "out" : "in"}
        onClose={onClose}
      />
      <ResetDialog open={request?.kind === "reset"} onClose={onClose} />
    </>
  );
}

function IncomeDialog({
  open,
  monthKey,
  onClose,
}: {
  open: boolean;
  monthKey: string;
  onClose: () => void;
}) {
  const addIncome = useBudget((state) => state.addIncome);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(defaultDateFor(monthKey));
  const [error, setError] = useState<string | null>(null);
  const bounds = monthBounds(monthKey);

  useEffect(() => {
    if (!open) return;
    setAmount("");
    setNote("");
    setDate(defaultDateFor(monthKey));
    setError(null);
  }, [open, monthKey]);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title="Registrar ingreso"
      description="Es el dinero que entra este mes, antes de repartirlo en sobres."
    >
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          const cents = parseAmountToCents(amount);
          if (cents == null || cents <= 0) {
            setError("Escribe un monto mayor a cero.");
            return;
          }
          const message = addIncome({ amountCents: cents, note, date });
          if (message) {
            setError(message);
            return;
          }
          onClose();
        }}
      >
        <Field label="Monto" error={error}>
          <Input
            inputMode="decimal"
            autoComplete="off"
            placeholder="1200"
            value={amount}
            onChange={(event) => {
              setAmount(event.target.value);
              setError(null);
            }}
            autoFocus
          />
        </Field>
        <Field label="Nota" hint="Opcional. Por ejemplo, nómina o venta.">
          <Input
            value={note}
            maxLength={80}
            placeholder="Nómina"
            onChange={(event) => setNote(event.target.value)}
          />
        </Field>
        <Field label="Fecha">
          <Input
            type="date"
            required
            min={bounds.min}
            max={bounds.max}
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </Field>
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="submit">Guardar ingreso</Button>
        </div>
      </form>
    </Modal>
  );
}

function ExpenseDialog({
  open,
  envelopeId,
  monthKey,
  onClose,
}: {
  open: boolean;
  envelopeId: string | null;
  monthKey: string;
  onClose: () => void;
}) {
  const data = useBudget();
  const envelope = data.envelopes.find((item) => item.id === envelopeId);
  const remaining = envelope ? envelopeLeftCents(data, monthKey, envelope.id) : 0;
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(defaultDateFor(monthKey));
  const [error, setError] = useState<string | null>(null);
  const bounds = monthBounds(monthKey);
  const cents = parseAmountToCents(amount);
  const hint =
    cents == null
      ? `Quedan ${formatMoney(remaining)} en este sobre.`
      : remaining - cents < 0
        ? `Te pasarías por ${formatMoney(cents - remaining)}. Igual puedes registrarlo.`
        : `Quedarían ${formatMoney(remaining - cents)}.`;

  useEffect(() => {
    if (!open) return;
    setAmount("");
    setNote("");
    setDate(defaultDateFor(monthKey));
    setError(null);
  }, [open, monthKey, envelopeId]);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title={envelope ? `Gasto en ${envelope.name}` : "Registrar gasto"}
      description="Se descuenta solo de este sobre, no del ahorro."
    >
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          if (!envelope) return;
          const parsed = parseAmountToCents(amount);
          if (parsed == null || parsed <= 0) {
            setError("Escribe un monto mayor a cero.");
            return;
          }
          const message = data.addExpense({
            envelopeId: envelope.id,
            amountCents: parsed,
            note,
            date,
          });
          if (message) {
            setError(message);
            return;
          }
          onClose();
        }}
      >
        <Field label="Monto" hint={error ? undefined : hint} error={error}>
          <Input
            inputMode="decimal"
            autoComplete="off"
            placeholder="18"
            value={amount}
            onChange={(event) => {
              setAmount(event.target.value);
              setError(null);
            }}
            autoFocus
          />
        </Field>
        <Field label="Nota" hint="Opcional. Por ejemplo, mercado o café.">
          <Input
            value={note}
            maxLength={80}
            placeholder="Mercado"
            onChange={(event) => setNote(event.target.value)}
          />
        </Field>
        <Field label="Fecha">
          <Input
            type="date"
            required
            min={bounds.min}
            max={bounds.max}
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </Field>
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="submit">Descontar</Button>
        </div>
      </form>
    </Modal>
  );
}

function EnvelopeDialog({
  open,
  envelopeId,
  monthKey,
  onClose,
}: {
  open: boolean;
  envelopeId?: string;
  monthKey: string;
  onClose: () => void;
}) {
  const data = useBudget();
  const existing = data.envelopes.find((item) => item.id === envelopeId);
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [error, setError] = useState<string | null>(null);
  const editing = Boolean(existing);
  const taken = new Set(
    data.envelopes.filter((item) => !item.archived).map((item) => item.name.toLocaleLowerCase("es")),
  );
  const ideas = SUGGESTIONS.filter((idea) => !taken.has(idea.toLocaleLowerCase("es")));

  useEffect(() => {
    if (!open) return;
    if (existing) {
      setName(existing.name);
      setAmount(centsToInput(effectiveAllocation(data, monthKey, existing.id)));
    } else {
      setName("");
      setAmount("");
    }
    setError(null);
    // Only reset when the dialog target changes, not on every store update.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, envelopeId, monthKey]);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title={editing ? "Ajustar sobre" : "Nuevo sobre"}
      description={
        editing
          ? `Cuánto destinas a ${existing?.name} en ${monthLabel(monthKey)}.`
          : "Un sobre es el dinero apartado para una cosa. Lo que no gastes se ahorra al cerrar el mes."
      }
    >
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          const cents = parseAmountToCents(amount);
          if (cents == null || (!editing && cents <= 0)) {
            setError(editing ? "Revisa el monto destinado." : "Destina un monto mayor a cero.");
            return;
          }
          const message = data.saveEnvelope({
            id: existing?.id,
            name,
            amountCents: cents,
            monthKey,
          });
          if (message) {
            setError(message);
            return;
          }
          onClose();
        }}
      >
        <Field label="Nombre">
          <Input
            value={name}
            maxLength={40}
            placeholder="Alimentación"
            onChange={(event) => {
              setName(event.target.value);
              setError(null);
            }}
            autoFocus
          />
        </Field>
        {!editing && ideas.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {ideas.map((idea) => (
              <button
                key={idea}
                type="button"
                className="min-h-11 rounded-sm border border-line bg-paper px-3 text-sm hover:bg-canvas"
                onClick={() => {
                  setName(idea);
                  setError(null);
                }}
              >
                {idea}
              </button>
            ))}
          </div>
        ) : null}
        <Field
          label="Destinado este mes"
          hint={
            editing
              ? "Si lo dejas igual el mes que viene, se repite solo."
              : "Por ejemplo, 80 para alimentación."
          }
          error={error}
        >
          <Input
            inputMode="decimal"
            autoComplete="off"
            placeholder="80"
            value={amount}
            onChange={(event) => {
              setAmount(event.target.value);
              setError(null);
            }}
          />
        </Field>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          {existing ? (
            <div className="flex gap-2">
              {envelopeHasExpenses(data, existing.id) ? (
                <Button
                  variant="secondary"
                  onClick={() => {
                    const message = data.setArchived(existing.id, !existing.archived);
                    if (message) {
                      setError(message);
                      return;
                    }
                    onClose();
                  }}
                >
                  {existing.archived ? "Reactivar" : "Archivar"}
                </Button>
              ) : (
                <Button
                  variant="danger"
                  onClick={() => {
                    const message = data.deleteEnvelope(existing.id);
                    if (message) {
                      setError(message);
                      return;
                    }
                    onClose();
                  }}
                >
                  Eliminar
                </Button>
              )}
            </div>
          ) : (
            <span />
          )}
          <div className="flex flex-col-reverse gap-2 sm:flex-row">
            <Button variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit">{editing ? "Guardar" : "Crear sobre"}</Button>
          </div>
        </div>
      </form>
    </Modal>
  );
}

function CloseDialog({
  open,
  monthKey,
  onClose,
}: {
  open: boolean;
  monthKey: string;
  onClose: () => void;
}) {
  const data = useBudget();
  const [includeUnassigned, setIncludeUnassigned] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const preview = closePreview(data, monthKey, includeUnassigned);
  const lines = preview.lines.filter((line) => line.allocatedCents > 0 || line.spentCents > 0);

  useEffect(() => {
    if (!open) return;
    setIncludeUnassigned(false);
    setError(null);
  }, [open, monthKey]);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title={`Cerrar ${monthLabel(monthKey)}`}
      description="Lo que quede en cada sobre pasa a ahorro. Después el mes queda bloqueado; puedes reabrirlo si te equivocaste."
    >
      <div className="space-y-4">
        {lines.length === 0 ? (
          <p className="text-sm text-muted">Ningún sobre tiene dinero apartado este mes.</p>
        ) : (
          <ul className="divide-y divide-line rounded-md border border-line">
            {lines.map((line) => (
              <li key={line.envelopeId} className="flex items-baseline justify-between gap-3 px-3 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{line.name}</p>
                  <p className="text-sm text-muted">
                    {line.leftCents < 0
                      ? `${formatMoney(line.spentCents)} gastados, ${formatMoney(-line.leftCents)} de más`
                      : `${formatMoney(line.spentCents)} de ${formatMoney(line.allocatedCents)}`}
                  </p>
                </div>
                <p className="shrink-0 text-sm font-medium tabular-nums">
                  {line.toSavingsCents > 0 ? formatMoney(line.toSavingsCents) : "$0"}
                </p>
              </li>
            ))}
          </ul>
        )}
        {preview.unassignedCents > 0 ? (
          <label className="flex min-h-11 items-start gap-3">
            <input
              type="checkbox"
              className="mt-1 size-5"
              checked={includeUnassigned}
              onChange={(event) => setIncludeUnassigned(event.target.checked)}
            />
            <span>
              <span className="block text-sm font-medium">Incluir dinero sin asignar</span>
              <span className="mt-1 block text-sm text-muted">
                {formatMoney(preview.unassignedCents)} entraron y no están en ningún sobre. Si no lo
                marcas, se quedan fuera del ahorro.
              </span>
            </span>
          </label>
        ) : null}
        {preview.unassignedCents < 0 ? (
          <p className="text-sm text-danger">
            Asignaste {formatMoney(-preview.unassignedCents)} más de lo que entró. El cierre no resta
            eso del ahorro: solo pasa lo que realmente sobró en cada sobre.
          </p>
        ) : null}
        <p className="font-display text-3xl tracking-tight tabular-nums">
          {formatMoney(preview.totalCents)}
        </p>
        <p className="text-sm text-muted">van a ahorro con este cierre.</p>
        {error ? (
          <p className="text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            onClick={() => {
              const message = data.closeMonth(monthKey, includeUnassigned);
              if (message) {
                setError(message);
                return;
              }
              onClose();
            }}
          >
            Pasar a ahorro
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function ReopenDialog({
  open,
  monthKey,
  onClose,
}: {
  open: boolean;
  monthKey: string;
  onClose: () => void;
}) {
  const reopenMonth = useBudget((state) => state.reopenMonth);
  const [error, setError] = useState<string | null>(null);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title={`Reabrir ${monthLabel(monthKey)}`}
      description="Vuelve a poder anotar gastos. El dinero que este cierre había pasado a ahorro se descuenta."
    >
      {error ? (
        <p className="mb-4 text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onClose}>
          Cancelar
        </Button>
        <Button
          onClick={() => {
            const message = reopenMonth(monthKey);
            if (message) {
              setError(message);
              return;
            }
            onClose();
          }}
        >
          Reabrir mes
        </Button>
      </div>
    </Modal>
  );
}

function DeleteTxDialog({
  open,
  id,
  onClose,
}: {
  open: boolean;
  id: string | null;
  onClose: () => void;
}) {
  const data = useBudget();
  const tx = data.transactions.find((item) => item.id === id);
  const [error, setError] = useState<string | null>(null);
  const envelope = data.envelopes.find((item) => item.id === tx?.envelopeId);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title="Eliminar movimiento"
      description={
        tx
          ? tx.kind === "income"
            ? `Se quita el ingreso de ${formatMoney(tx.amountCents)}.`
            : `Se devuelven ${formatMoney(tx.amountCents)} a ${envelope?.name ?? "el sobre"}.`
          : "Este movimiento ya no está."
      }
    >
      {error ? (
        <p className="mb-4 text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onClose}>
          Cancelar
        </Button>
        <Button
          variant="danger"
          onClick={() => {
            if (!tx) return;
            const message = data.removeTransaction(tx.id);
            if (message) {
              setError(message);
              return;
            }
            onClose();
          }}
        >
          Eliminar
        </Button>
      </div>
    </Modal>
  );
}

function SavingsDialog({
  open,
  mode,
  onClose,
}: {
  open: boolean;
  mode: "in" | "out";
  onClose: () => void;
}) {
  const moveSavings = useBudget((state) => state.moveSavings);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setAmount("");
    setNote("");
    setError(null);
  }, [open, mode]);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title={mode === "in" ? "Apartar en ahorro" : "Retirar de ahorro"}
      description={
        mode === "in"
          ? "Un movimiento manual, aparte de lo que llega al cerrar el mes."
          : "Sale de tu ahorro acumulado. No vuelve a un sobre."
      }
    >
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          const cents = parseAmountToCents(amount);
          if (cents == null || cents <= 0) {
            setError("Escribe un monto mayor a cero.");
            return;
          }
          const message = moveSavings(mode === "in" ? cents : -cents, note);
          if (message) {
            setError(message);
            return;
          }
          onClose();
        }}
      >
        <Field label="Monto" error={error}>
          <Input
            inputMode="decimal"
            autoComplete="off"
            placeholder="20"
            value={amount}
            onChange={(event) => {
              setAmount(event.target.value);
              setError(null);
            }}
            autoFocus
          />
        </Field>
        <Field label="Nota" hint="Opcional.">
          <Input
            value={note}
            maxLength={80}
            onChange={(event) => setNote(event.target.value)}
          />
        </Field>
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="submit">{mode === "in" ? "Apartar" : "Retirar"}</Button>
        </div>
      </form>
    </Modal>
  );
}

function ResetDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const reset = useBudget((state) => state.reset);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title="Borrar todo"
      description="Se elimina la libreta de este dispositivo. No se puede deshacer."
    >
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onClose}>
          Cancelar
        </Button>
        <Button
          variant="danger"
          onClick={() => {
            reset();
            onClose();
          }}
        >
          Borrar todo
        </Button>
      </div>
    </Modal>
  );
}
