import { ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { BudgetDialogs, type DialogRequest } from "@/components/sobres/dialogs";
import { Button } from "@/components/ui/button";
import {
  allocationOrigin,
  effectiveAllocation,
  envelopeLeftCents,
  incomeCents,
  monthEnvelopes,
  savingsBalance,
  serializeBackup,
  spentCents,
  unassignedCents,
} from "@/lib/budget-math";
import { useBudget } from "@/lib/budget-store";
import {
  formatDay,
  formatMoney,
  formatStamp,
  monthKeyFromDate,
  monthLabel,
  shiftMonth,
} from "@/lib/money";
import { cn } from "@/lib/utils";

type Tab = "mes" | "movimientos" | "ahorro";

const STEPS = [
  {
    title: "Entra",
    body: "Anota el dinero del mes: sueldo, ventas o lo que haya llegado.",
  },
  {
    title: "Aparta",
    body: "Destina un monto a cada sobre. Por ejemplo, $80 para alimentación.",
  },
  {
    title: "Gasta y cierra",
    body: "Cada compra se descuenta de ese sobre. Al cerrar el mes, lo que sobra pasa a ahorro.",
  },
];

function useBudgetReady() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let alive = true;
    const finish = () => {
      if (alive) setReady(true);
    };
    const unsubscribe = useBudget.persist.onFinishHydration(finish);
    if (useBudget.persist.hasHydrated()) finish();
    else void useBudget.persist.rehydrate();
    return () => {
      alive = false;
      unsubscribe();
    };
  }, []);
  return ready;
}

export function SobresApp() {
  const ready = useBudgetReady();
  if (!ready) return <LoadingShell />;
  return <BudgetScreen />;
}

function LoadingShell() {
  return (
    <main className="mx-auto min-h-screen max-w-5xl px-4 py-8" aria-busy="true">
      <p className="text-sm text-muted">En este dispositivo</p>
      <h1 className="mt-1 font-display text-4xl tracking-tight">Sobres</h1>
      <p className="mt-3 text-sm text-muted">Abriendo tu libreta…</p>
      <div className="mt-8 h-40 rounded-lg border border-line bg-paper" />
      <div className="mt-4 h-28 rounded-lg border border-line bg-paper" />
    </main>
  );
}

function BudgetScreen() {
  const data = useBudget();
  const currentKey = monthKeyFromDate(new Date());
  const [monthKey, setMonthKey] = useState(currentKey);
  const [tab, setTab] = useState<Tab>("mes");
  const [dialog, setDialog] = useState<DialogRequest>(null);
  const closed = data.closedMonths.includes(monthKey);
  const closable = monthKey <= currentKey;
  const envelopes = monthEnvelopes(data, monthKey).filter((envelope) => {
    if (!closed) return true;
    return (
      effectiveAllocation(data, monthKey, envelope.id) > 0 ||
      spentCents(data, monthKey, envelope.id) > 0
    );
  });
  const income = incomeCents(data, monthKey);
  const spent = spentCents(data, monthKey);
  const loose = unassignedCents(data, monthKey);
  const saved = savingsBalance(data);
  const closeEntry = data.savings.find((item) => item.source === "close" && item.monthKey === monthKey);
  const projected = envelopes.reduce(
    (sum, envelope) => sum + Math.max(0, envelopeLeftCents(data, monthKey, envelope.id)),
    0,
  );
  const heroAmount = closed ? (closeEntry?.amountCents ?? 0) : projected;
  const started = income > 0 || envelopes.length > 0 || spent > 0 || data.transactions.some((tx) => tx.monthKey === monthKey);

  return (
    <main className="mx-auto min-h-screen max-w-5xl px-4 py-6 pb-10">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm text-muted">En este dispositivo</p>
          <h1 className="mt-1 font-display text-4xl tracking-tight">Sobres</h1>
          <p className="mt-2 max-w-md text-sm text-muted">
            Aparta, gasta y lo que sobre se ahorra. Sin cuenta y sin internet.
          </p>
        </div>
        <MonthSwitcher monthKey={monthKey} currentKey={currentKey} onChange={setMonthKey} />
      </header>

      <div
        role="tablist"
        aria-label="Secciones"
        className="mt-6 flex gap-1 rounded-md border border-line bg-paper p-1"
      >
        {(
          [
            ["mes", "Mes"],
            ["movimientos", "Movimientos"],
            ["ahorro", "Ahorro"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={tab === id}
            className={cn(
              "min-h-11 flex-1 rounded-sm text-sm font-medium",
              tab === id ? "bg-accent text-accent-fg" : "text-muted hover:bg-canvas hover:text-ink",
            )}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="mt-6 grid items-start gap-6 lg:grid-cols-[20rem_minmax(0,1fr)]">
        <aside className={cn("space-y-4 lg:sticky lg:top-4", tab !== "mes" && "hidden lg:block")}>
          <section className="rounded-lg border border-line bg-paper p-6">
            {started ? (
              <>
                <p className="text-sm text-muted">
                  {closed ? "Pasó a ahorro" : "Si cierras hoy, pasa a ahorro"}
                </p>
                <p className="mt-3 font-display text-4xl tracking-tight tabular-nums">
                  {formatMoney(heroAmount)}
                </p>
                <p className="mt-3 text-sm text-muted">
                  {closed
                    ? closeEntry
                      ? closeEntry.note
                      : "No sobró nada en los sobres."
                    : "Es lo que queda en cada sobre, ya descontados los gastos."}
                </p>
              </>
            ) : (
              <>
                <p className="text-sm text-muted">Cómo funciona</p>
                <p className="mt-3 font-display text-3xl tracking-tight">Tu mes, en sobres</p>
                <ol className="mt-5 space-y-4">
                  {STEPS.map((step, index) => (
                    <li key={step.title} className="flex gap-3">
                      <span className="flex size-8 shrink-0 items-center justify-center rounded-sm bg-track text-sm font-medium">
                        {index + 1}
                      </span>
                      <span>
                        <span className="block font-medium">{step.title}</span>
                        <span className="mt-1 block text-sm text-muted">{step.body}</span>
                      </span>
                    </li>
                  ))}
                </ol>
              </>
            )}
          </section>

          {started ? (
            <dl className="grid grid-cols-3 gap-2">
              <Stat label="Entró" value={income} />
              <Stat label="Gastado" value={spent} />
              <Stat label="Sin asignar" value={loose} signed />
            </dl>
          ) : null}

          {started && loose !== 0 ? (
            <p className="text-sm text-muted">
              {loose > 0
                ? `${formatMoney(loose)} todavía no están en un sobre. No se ahorran solos: márcalo al cerrar el mes, o apártalo.`
                : `Asignaste ${formatMoney(-loose)} más de lo que entró este mes.`}
            </p>
          ) : null}

          <div className="flex flex-col gap-2">
            {!closed ? (
              <>
                <Button onClick={() => setDialog({ kind: "income" })}>Registrar ingreso</Button>
                <Button variant="secondary" onClick={() => setDialog({ kind: "envelope" })}>
                  Nuevo sobre
                </Button>
              </>
            ) : null}
            {closed ? (
              <Button variant="secondary" onClick={() => setDialog({ kind: "reopen" })}>
                Reabrir mes
              </Button>
            ) : closable && started ? (
              <Button variant="secondary" onClick={() => setDialog({ kind: "close" })}>
                Cerrar mes
              </Button>
            ) : !closable ? (
              <p className="text-sm text-muted">Este mes todavía no llega. Puedes dejar los sobres listos.</p>
            ) : null}
          </div>

          {data.savings.length > 0 ? (
            <button
              type="button"
              className="min-h-11 text-left text-sm text-muted"
              onClick={() => setTab("ahorro")}
            >
              Ahorro acumulado{" "}
              <span className="font-medium text-ink tabular-nums">{formatMoney(saved)}</span>
            </button>
          ) : null}
        </aside>

        <section>
          {tab === "mes" ? (
            <MonthPanel
              monthKey={monthKey}
              closed={closed}
              envelopes={envelopes}
              onExpense={(envelopeId) => setDialog({ kind: "expense", envelopeId })}
              onEdit={(envelopeId) => setDialog({ kind: "envelope", envelopeId })}
              onCreate={() => setDialog({ kind: "envelope" })}
              onNext={() => setMonthKey(shiftMonth(monthKey, 1))}
            />
          ) : null}
          {tab === "movimientos" ? (
            <Movements monthKey={monthKey} closed={closed} onDelete={(id) => setDialog({ kind: "delete-tx", id })} />
          ) : null}
          {tab === "ahorro" ? (
            <SavingsPanel
              onIn={() => setDialog({ kind: "savings-in" })}
              onOut={() => setDialog({ kind: "savings-out" })}
              onReset={() => setDialog({ kind: "reset" })}
            />
          ) : null}
        </section>
      </div>

      <BudgetDialogs request={dialog} monthKey={monthKey} onClose={() => setDialog(null)} />
    </main>
  );
}

function Stat({ label, value, signed = false }: { label: string; value: number; signed?: boolean }) {
  return (
    <div className="min-w-0 rounded-md border border-line bg-paper px-3 py-3">
      <dt className="text-xs text-muted">{label}</dt>
      <dd
        className={cn(
          "mt-1 truncate text-sm font-medium tabular-nums",
          signed && value < 0 && "text-danger",
        )}
      >
        {formatMoney(value)}
      </dd>
    </div>
  );
}

function MonthSwitcher({
  monthKey,
  currentKey,
  onChange,
}: {
  monthKey: string;
  currentKey: string;
  onChange: (monthKey: string) => void;
}) {
  return (
    <div className="flex items-center gap-1">
      <Button
        variant="ghost"
        size="icon"
        aria-label="Mes anterior"
        onClick={() => onChange(shiftMonth(monthKey, -1))}
      >
        <ChevronLeft className="size-4" aria-hidden="true" />
      </Button>
      <div className="min-w-36 text-center">
        <p className="text-sm font-medium">{monthLabel(monthKey)}</p>
        {monthKey !== currentKey ? (
          <button
            type="button"
            className="mt-1 min-h-11 text-sm text-muted"
            onClick={() => onChange(currentKey)}
          >
            Volver a este mes
          </button>
        ) : null}
      </div>
      <Button
        variant="ghost"
        size="icon"
        aria-label="Mes siguiente"
        onClick={() => onChange(shiftMonth(monthKey, 1))}
      >
        <ChevronRight className="size-4" aria-hidden="true" />
      </Button>
    </div>
  );
}

function MonthPanel({
  monthKey,
  closed,
  envelopes,
  onExpense,
  onEdit,
  onCreate,
  onNext,
}: {
  monthKey: string;
  closed: boolean;
  envelopes: ReturnType<typeof monthEnvelopes>;
  onExpense: (envelopeId: string) => void;
  onEdit: (envelopeId: string) => void;
  onCreate: () => void;
  onNext: () => void;
}) {
  const data = useBudget();
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-medium">Sobres</h2>
      </div>
      {closed ? (
        <div className="rounded-lg border border-line bg-paper px-4 py-4">
          <p className="font-medium">Este mes está cerrado.</p>
          <p className="mt-1 text-sm text-muted">
            Lo que sobró ya está en ahorro. Reábrelo arriba si necesitas corregir un gasto.
          </p>
          <Button variant="secondary" className="mt-3 w-full" onClick={onNext}>
            Ir a {monthLabel(shiftMonth(monthKey, 1))}
          </Button>
        </div>
      ) : null}
      {envelopes.length === 0 ? (
        <div className="rounded-lg border border-line bg-paper p-6">
          <h3 className="font-medium">Todavía no hay sobres</h3>
          <p className="mt-2 text-sm text-muted">
            Aparta un monto, por ejemplo $80 para alimentación. Cuando compres, se resta de ahí.
          </p>
          {!closed ? (
            <Button className="mt-4" onClick={onCreate}>
              Crear sobre
            </Button>
          ) : null}
        </div>
      ) : (
        envelopes.map((envelope) => {
          const allocated = effectiveAllocation(data, monthKey, envelope.id);
          const spent = spentCents(data, monthKey, envelope.id);
          const left = allocated - spent;
          const ratio = allocated <= 0 ? (spent > 0 ? 1 : 0) : Math.min(1, spent / allocated);
          const origin = allocationOrigin(data, monthKey, envelope.id);
          return (
            <article key={envelope.id} className="rounded-lg border border-line bg-paper p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="truncate text-base font-medium">{envelope.name}</h3>
                  <p className="mt-1 text-sm text-muted">
                    {formatMoney(allocated)} destinados · {formatMoney(spent)} gastados
                  </p>
                  {origin === "carried" && !closed ? (
                    <p className="mt-1 text-sm text-faint">Mismo monto que el mes anterior.</p>
                  ) : null}
                </div>
                <div className="text-right">
                  <p
                    className={cn(
                      "font-display text-2xl tracking-tight tabular-nums",
                      left < 0 && "text-danger",
                    )}
                  >
                    {formatMoney(left)}
                  </p>
                  <p className="text-xs text-muted">{closed ? (left < 0 ? "de más" : "sobraron") : left < 0 ? "de más" : "quedan"}</p>
                </div>
              </div>
              <div
                className="meter mt-4"
                role="progressbar"
                aria-valuemin={0}
                aria-valuemax={Math.max(allocated, 1)}
                aria-valuenow={Math.min(spent, Math.max(allocated, spent))}
                aria-label={`Gastado en ${envelope.name}`}
              >
                <span data-over={left < 0 ? "true" : "false"} style={{ width: `${ratio * 100}%` }} />
              </div>
              {!closed ? (
                <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                  {allocated === 0 && spent === 0 ? (
                    <Button className="sm:flex-1" onClick={() => onEdit(envelope.id)}>
                      Asignar monto
                    </Button>
                  ) : (
                    <>
                      <Button className="sm:flex-1" onClick={() => onExpense(envelope.id)}>
                        Registrar gasto
                      </Button>
                      <Button variant="secondary" onClick={() => onEdit(envelope.id)}>
                        Ajustar
                      </Button>
                    </>
                  )}
                </div>
              ) : null}
            </article>
          );
        })
      )}
    </div>
  );
}

function Movements({
  monthKey,
  closed,
  onDelete,
}: {
  monthKey: string;
  closed: boolean;
  onDelete: (id: string) => void;
}) {
  const transactions = useBudget((state) => state.transactions);
  const envelopes = useBudget((state) => state.envelopes);
  const rows = transactions
    .filter((tx) => tx.monthKey === monthKey)
    .sort((a, b) => {
      if (a.date !== b.date) return a.date < b.date ? 1 : -1;
      return a.createdAt < b.createdAt ? 1 : -1;
    });

  if (rows.length === 0) {
    return (
      <div className="rounded-lg border border-line bg-paper p-6">
        <h2 className="font-medium">Sin movimientos</h2>
        <p className="mt-2 text-sm text-muted">
          Los ingresos y los gastos de {monthLabel(monthKey)} aparecen aquí.
        </p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-lg font-medium">Movimientos</h2>
      <ul className="mt-3 divide-y divide-line rounded-lg border border-line bg-paper">
        {rows.map((tx) => {
          const name =
            tx.kind === "income"
              ? "Ingreso"
              : (envelopes.find((envelope) => envelope.id === tx.envelopeId)?.name ?? "Gasto");
          return (
            <li key={tx.id} className="flex items-center gap-3 px-4 py-3">
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{name}</p>
                <p className="truncate text-sm text-muted">
                  {formatDay(tx.date)}
                  {tx.note ? ` · ${tx.note}` : ""}
                </p>
              </div>
              <p className="shrink-0 text-sm font-medium tabular-nums">
                {tx.kind === "income" ? "+" : "−"}
                {formatMoney(tx.amountCents)}
              </p>
              {!closed ? (
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={`Eliminar ${name}`}
                  onClick={() => onDelete(tx.id)}
                >
                  <Trash2 className="size-4" aria-hidden="true" />
                </Button>
              ) : null}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function SavingsPanel({
  onIn,
  onOut,
  onReset,
}: {
  onIn: () => void;
  onOut: () => void;
  onReset: () => void;
}) {
  const data = useBudget();
  const balance = savingsBalance(data);
  const moves = [...data.savings].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  const fileRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      <section className="rounded-lg border border-line bg-paper p-6">
        <p className="text-sm text-muted">Ahorro acumulado</p>
        <p className="mt-3 font-display text-4xl tracking-tight tabular-nums">{formatMoney(balance)}</p>
        <p className="mt-3 text-sm text-muted">
          Crece cuando cierras un mes y sobra dinero en los sobres.
        </p>
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <Button onClick={onIn}>Apartar</Button>
          <Button variant="secondary" onClick={onOut} disabled={balance <= 0}>
            Retirar
          </Button>
        </div>
      </section>

      <section>
        <h2 className="text-lg font-medium">Historial</h2>
        {moves.length === 0 ? (
          <p className="mt-2 text-sm text-muted">Aquí verás cada cierre de mes.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line rounded-lg border border-line bg-paper">
            {moves.map((move) => (
              <li key={move.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate font-medium">{move.note}</p>
                  <p className="text-sm text-muted">{formatStamp(move.createdAt)}</p>
                </div>
                <p className="shrink-0 text-sm font-medium tabular-nums">
                  {move.amountCents > 0 ? "+" : "−"}
                  {formatMoney(Math.abs(move.amountCents))}
                </p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="rounded-lg border border-line bg-paper p-4">
        <h2 className="font-medium">Copia en este dispositivo</h2>
        <p className="mt-2 text-sm text-muted">
          Nada sale de este navegador. Descarga una copia si vas a cambiar de teléfono.
        </p>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <Button
            variant="secondary"
            onClick={() => {
              const blob = new Blob([serializeBackup(data)], { type: "application/json" });
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.href = url;
              link.download = "sobres-copia.json";
              document.body.appendChild(link);
              link.click();
              link.remove();
              URL.revokeObjectURL(url);
            }}
          >
            Descargar copia
          </Button>
          <Button variant="secondary" onClick={() => fileRef.current?.click()}>
            Restaurar copia
          </Button>
          <Button variant="danger" onClick={onReset}>
            Borrar todo
          </Button>
        </div>
        <input
          ref={fileRef}
          className="sr-only"
          type="file"
          accept="application/json"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => {
              try {
                const parsed = JSON.parse(String(reader.result));
                const message = data.importBackup(parsed);
                setError(message);
              } catch {
                setError("No se pudo leer el archivo.");
              }
            };
            reader.readAsText(file);
          }}
        />
        {error ? (
          <p className="mt-3 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}
      </section>
    </div>
  );
}
