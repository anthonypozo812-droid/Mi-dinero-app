import { MAX_CENTS, monthLabel } from "./money.ts";

export type Envelope = {
  id: string;
  name: string;
  archived: boolean;
  createdAt: string;
};

export type Allocation = {
  envelopeId: string;
  monthKey: string;
  amountCents: number;
};

export type Transaction = {
  id: string;
  kind: "income" | "expense";
  envelopeId: string | null;
  amountCents: number;
  note: string;
  date: string;
  monthKey: string;
  createdAt: string;
};

export type SavingsMove = {
  id: string;
  amountCents: number;
  note: string;
  monthKey: string | null;
  source: "close" | "manual";
  createdAt: string;
};

export type BudgetData = {
  envelopes: Envelope[];
  allocations: Allocation[];
  transactions: Transaction[];
  savings: SavingsMove[];
  closedMonths: string[];
};

export const emptyData: BudgetData = {
  envelopes: [],
  allocations: [],
  transactions: [],
  savings: [],
  closedMonths: [],
};

export type Ok = { ok: true; data: BudgetData };
export type Err = { ok: false; error: string };
export type Result = Ok | Err;

export type CloseLine = {
  envelopeId: string;
  name: string;
  allocatedCents: number;
  spentCents: number;
  leftCents: number;
  toSavingsCents: number;
};

export type ClosePreview = {
  lines: CloseLine[];
  unassignedCents: number;
  unassignedToSavingsCents: number;
  envelopeSavingsCents: number;
  totalCents: number;
  note: string;
};

const MONTH = /^\d{4}-\d{2}$/;
const DAY = /^\d{4}-\d{2}-\d{2}$/;

export function incomeCents(data: BudgetData, monthKey: string) {
  return data.transactions.reduce((sum, tx) => {
    if (tx.kind === "income" && tx.monthKey === monthKey) return sum + tx.amountCents;
    return sum;
  }, 0);
}

export function spentCents(data: BudgetData, monthKey: string, envelopeId?: string) {
  return data.transactions.reduce((sum, tx) => {
    if (tx.kind !== "expense" || tx.monthKey !== monthKey) return sum;
    if (envelopeId && tx.envelopeId !== envelopeId) return sum;
    return sum + tx.amountCents;
  }, 0);
}

export function explicitAllocation(data: BudgetData, monthKey: string, envelopeId: string) {
  return data.allocations.find(
    (item) => item.envelopeId === envelopeId && item.monthKey === monthKey,
  );
}

export function effectiveAllocation(data: BudgetData, monthKey: string, envelopeId: string) {
  const exact = explicitAllocation(data, monthKey, envelopeId);
  if (exact) return exact.amountCents;
  const envelope = data.envelopes.find((item) => item.id === envelopeId);
  if (!envelope || envelope.archived) return 0;
  const prior = data.allocations
    .filter((item) => item.envelopeId === envelopeId && item.monthKey < monthKey)
    .sort((a, b) => (a.monthKey < b.monthKey ? 1 : -1))[0];
  return prior?.amountCents ?? 0;
}

export function allocationOrigin(
  data: BudgetData,
  monthKey: string,
  envelopeId: string,
): "explicit" | "carried" | "none" {
  if (explicitAllocation(data, monthKey, envelopeId)) return "explicit";
  const envelope = data.envelopes.find((item) => item.id === envelopeId);
  if (!envelope || envelope.archived) return "none";
  const carried = data.allocations.some(
    (item) => item.envelopeId === envelopeId && item.monthKey < monthKey,
  );
  return carried ? "carried" : "none";
}

export function monthEnvelopes(data: BudgetData, monthKey: string) {
  const closed = data.closedMonths.includes(monthKey);
  return data.envelopes
    .filter((envelope) => {
      const explicit = Boolean(explicitAllocation(data, monthKey, envelope.id));
      const spent = spentCents(data, monthKey, envelope.id) > 0;
      if (closed) return explicit || spent;
      if (!envelope.archived) return true;
      return explicit || spent;
    })
    .sort((a, b) => (a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0));
}

export function envelopeLeftCents(data: BudgetData, monthKey: string, envelopeId: string) {
  return (
    effectiveAllocation(data, monthKey, envelopeId) - spentCents(data, monthKey, envelopeId)
  );
}

export function assignedCents(data: BudgetData, monthKey: string) {
  return monthEnvelopes(data, monthKey).reduce(
    (sum, envelope) => sum + effectiveAllocation(data, monthKey, envelope.id),
    0,
  );
}

export function unassignedCents(data: BudgetData, monthKey: string) {
  return incomeCents(data, monthKey) - assignedCents(data, monthKey);
}

export function savingsBalance(data: BudgetData) {
  return data.savings.reduce((sum, move) => sum + move.amountCents, 0);
}

export function envelopeHasExpenses(data: BudgetData, envelopeId: string) {
  return data.transactions.some((tx) => tx.envelopeId === envelopeId);
}

export function closePreview(
  data: BudgetData,
  monthKey: string,
  includeUnassigned: boolean,
): ClosePreview {
  const lines = monthEnvelopes(data, monthKey).map((envelope) => {
    const allocated = effectiveAllocation(data, monthKey, envelope.id);
    const spent = spentCents(data, monthKey, envelope.id);
    const left = allocated - spent;
    return {
      envelopeId: envelope.id,
      name: envelope.name,
      allocatedCents: allocated,
      spentCents: spent,
      leftCents: left,
      toSavingsCents: Math.max(0, left),
    };
  });
  const envelopeSavingsCents = lines.reduce((sum, line) => sum + line.toSavingsCents, 0);
  const unassigned = unassignedCents(data, monthKey);
  const unassignedToSavingsCents = includeUnassigned ? Math.max(0, unassigned) : 0;
  const note =
    includeUnassigned && unassignedToSavingsCents > 0
      ? `Cierre de ${monthLabel(monthKey)}: sobres y dinero sin asignar`
      : `Cierre de ${monthLabel(monthKey)}`;
  return {
    lines,
    unassignedCents: unassigned,
    unassignedToSavingsCents,
    envelopeSavingsCents,
    totalCents: envelopeSavingsCents + unassignedToSavingsCents,
    note,
  };
}

function fail(error: string): Err {
  return { ok: false, error };
}

export function addTransaction(
  data: BudgetData,
  input: {
    kind: "income" | "expense";
    amountCents: number;
    note: string;
    date: string;
    envelopeId?: string | null;
    id: string;
    now: string;
  },
): Result {
  if (!DAY.test(input.date)) return fail("Fecha inválida.");
  const monthKey = input.date.slice(0, 7);
  if (data.closedMonths.includes(monthKey)) return fail("Ese mes está cerrado.");
  if (!Number.isInteger(input.amountCents) || input.amountCents <= 0 || input.amountCents > MAX_CENTS) {
    return fail("Escribe un monto mayor a cero.");
  }
  let envelopeId: string | null = null;
  if (input.kind === "expense") {
    const envelope = data.envelopes.find((item) => item.id === input.envelopeId);
    if (!envelope) return fail("Elige un sobre.");
    envelopeId = envelope.id;
  }
  const tx: Transaction = {
    id: input.id,
    kind: input.kind,
    envelopeId,
    amountCents: input.amountCents,
    note: input.note.trim().slice(0, 80),
    date: input.date,
    monthKey,
    createdAt: input.now,
  };
  return { ok: true, data: { ...data, transactions: [...data.transactions, tx] } };
}

export function removeTransaction(data: BudgetData, id: string): Result {
  const tx = data.transactions.find((item) => item.id === id);
  if (!tx) return fail("No se encontró el movimiento.");
  if (data.closedMonths.includes(tx.monthKey)) return fail("Ese mes está cerrado.");
  return {
    ok: true,
    data: { ...data, transactions: data.transactions.filter((item) => item.id !== id) },
  };
}

export function saveEnvelope(
  data: BudgetData,
  input: {
    id?: string;
    name: string;
    amountCents: number;
    monthKey: string;
    idIfNew: string;
    now: string;
  },
): Result {
  const name = input.name.trim();
  if (name.length < 1 || name.length > 40) return fail("El nombre necesita entre 1 y 40 caracteres.");
  if (!MONTH.test(input.monthKey)) return fail("Mes inválido.");
  if (data.closedMonths.includes(input.monthKey)) return fail("Ese mes está cerrado.");
  if (
    !Number.isInteger(input.amountCents) ||
    input.amountCents < 0 ||
    input.amountCents > MAX_CENTS
  ) {
    return fail("Revisa el monto destinado.");
  }
  if (!input.id && input.amountCents <= 0) return fail("Destina un monto mayor a cero.");
  const duplicate = data.envelopes.some(
    (envelope) =>
      !envelope.archived &&
      envelope.id !== input.id &&
      envelope.name.toLocaleLowerCase("es") === name.toLocaleLowerCase("es"),
  );
  if (duplicate) return fail("Ya tienes un sobre con ese nombre.");

  if (!input.id) {
    const envelope: Envelope = {
      id: input.idIfNew,
      name,
      archived: false,
      createdAt: input.now,
    };
    return {
      ok: true,
      data: {
        ...data,
        envelopes: [...data.envelopes, envelope],
        allocations: [
          ...data.allocations,
          { envelopeId: envelope.id, monthKey: input.monthKey, amountCents: input.amountCents },
        ],
      },
    };
  }

  if (!data.envelopes.some((envelope) => envelope.id === input.id)) {
    return fail("No se encontró el sobre.");
  }
  return {
    ok: true,
    data: {
      ...data,
      envelopes: data.envelopes.map((envelope) =>
        envelope.id === input.id ? { ...envelope, name } : envelope,
      ),
      allocations: [
        ...data.allocations.filter(
          (item) => !(item.envelopeId === input.id && item.monthKey === input.monthKey),
        ),
        { envelopeId: input.id, monthKey: input.monthKey, amountCents: input.amountCents },
      ],
    },
  };
}

export function setArchived(data: BudgetData, id: string, archived: boolean): Result {
  if (!data.envelopes.some((envelope) => envelope.id === id)) return fail("No se encontró el sobre.");
  return {
    ok: true,
    data: {
      ...data,
      envelopes: data.envelopes.map((envelope) =>
        envelope.id === id ? { ...envelope, archived } : envelope,
      ),
    },
  };
}

export function deleteEnvelope(data: BudgetData, id: string): Result {
  if (!data.envelopes.some((envelope) => envelope.id === id)) return fail("No se encontró el sobre.");
  if (envelopeHasExpenses(data, id)) {
    return fail("Este sobre ya tiene gastos. Archívalo para ocultarlo sin perder el historial.");
  }
  return {
    ok: true,
    data: {
      ...data,
      envelopes: data.envelopes.filter((envelope) => envelope.id !== id),
      allocations: data.allocations.filter((item) => item.envelopeId !== id),
    },
  };
}

export function applyClose(
  data: BudgetData,
  monthKey: string,
  includeUnassigned: boolean,
  now: string,
  id: string,
): Result {
  if (!MONTH.test(monthKey)) return fail("Mes inválido.");
  if (data.closedMonths.includes(monthKey)) return fail("Ese mes ya está cerrado.");
  const preview = closePreview(data, monthKey, includeUnassigned);
  const active = data.envelopes.filter((envelope) => !envelope.archived);
  const materialized: Allocation[] = active.map((envelope) => ({
    envelopeId: envelope.id,
    monthKey,
    amountCents: effectiveAllocation(data, monthKey, envelope.id),
  }));
  const savings =
    preview.totalCents > 0
      ? [
          ...data.savings,
          {
            id,
            amountCents: preview.totalCents,
            note: preview.note,
            monthKey,
            source: "close" as const,
            createdAt: now,
          },
        ]
      : data.savings;
  return {
    ok: true,
    data: {
      ...data,
      allocations: [...data.allocations.filter((item) => item.monthKey !== monthKey), ...materialized],
      savings,
      closedMonths: [...data.closedMonths, monthKey],
    },
  };
}

export function applyReopen(data: BudgetData, monthKey: string): Result {
  if (!data.closedMonths.includes(monthKey)) return fail("Ese mes no está cerrado.");
  return {
    ok: true,
    data: {
      ...data,
      closedMonths: data.closedMonths.filter((item) => item !== monthKey),
      savings: data.savings.filter((item) => !(item.source === "close" && item.monthKey === monthKey)),
    },
  };
}

export function addSavings(
  data: BudgetData,
  input: { amountCents: number; note: string; id: string; now: string },
): Result {
  if (!Number.isInteger(input.amountCents) || input.amountCents === 0) {
    return fail("Escribe un monto mayor a cero.");
  }
  if (Math.abs(input.amountCents) > MAX_CENTS) return fail("Ese monto es demasiado alto.");
  if (savingsBalance(data) + input.amountCents < 0) {
    return fail("No puedes retirar más de lo ahorrado.");
  }
  const move: SavingsMove = {
    id: input.id,
    amountCents: input.amountCents,
    note: input.note.trim().slice(0, 80) || (input.amountCents > 0 ? "Apartado manual" : "Retiro"),
    monthKey: null,
    source: "manual",
    createdAt: input.now,
  };
  return { ok: true, data: { ...data, savings: [...data.savings, move] } };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function isCents(value: unknown, allowNegative: boolean): value is number {
  return (
    typeof value === "number" &&
    Number.isInteger(value) &&
    value <= MAX_CENTS &&
    (allowNegative ? value >= -MAX_CENTS : value >= 0)
  );
}

export function parseBackup(raw: unknown): BudgetData | null {
  if (!isRecord(raw)) return null;
  const payload = raw.app === "sobres" && isRecord(raw.data) ? raw.data : raw;
  if (!isRecord(payload)) return null;
  if (
    !Array.isArray(payload.envelopes) ||
    !Array.isArray(payload.allocations) ||
    !Array.isArray(payload.transactions) ||
    !Array.isArray(payload.savings) ||
    !Array.isArray(payload.closedMonths)
  ) {
    return null;
  }
  if (
    payload.envelopes.length > 5000 ||
    payload.allocations.length > 5000 ||
    payload.transactions.length > 5000 ||
    payload.savings.length > 5000 ||
    payload.closedMonths.length > 5000
  ) {
    return null;
  }

  const envelopes: Envelope[] = [];
  const envelopeIds = new Set<string>();
  for (const item of payload.envelopes) {
    if (!isRecord(item)) return null;
    if (typeof item.id !== "string" || item.id.length < 1 || item.id.length > 80) return null;
    if (typeof item.name !== "string" || item.name.trim().length < 1 || item.name.length > 40) return null;
    if (typeof item.archived !== "boolean") return null;
    if (typeof item.createdAt !== "string" || item.createdAt.length > 40) return null;
    if (envelopeIds.has(item.id)) return null;
    envelopeIds.add(item.id);
    envelopes.push({
      id: item.id,
      name: item.name.trim(),
      archived: item.archived,
      createdAt: item.createdAt,
    });
  }

  const allocations: Allocation[] = [];
  const allocationKeys = new Set<string>();
  for (const item of payload.allocations) {
    if (!isRecord(item)) return null;
    if (typeof item.envelopeId !== "string" || !envelopeIds.has(item.envelopeId)) return null;
    if (typeof item.monthKey !== "string" || !MONTH.test(item.monthKey)) return null;
    const amountCents = item.amountCents;
    if (!isCents(amountCents, false)) return null;
    const key = `${item.envelopeId}:${item.monthKey}`;
    if (allocationKeys.has(key)) return null;
    allocationKeys.add(key);
    allocations.push({
      envelopeId: item.envelopeId,
      monthKey: item.monthKey,
      amountCents,
    });
  }

  const transactions: Transaction[] = [];
  const txIds = new Set<string>();
  for (const item of payload.transactions) {
    if (!isRecord(item)) return null;
    if (typeof item.id !== "string" || item.id.length < 1 || item.id.length > 80) return null;
    if (item.kind !== "income" && item.kind !== "expense") return null;
    if (typeof item.date !== "string" || !DAY.test(item.date)) return null;
    if (typeof item.monthKey !== "string" || item.monthKey !== item.date.slice(0, 7)) return null;
    const amountCents = item.amountCents;
    if (!isCents(amountCents, false) || amountCents === 0) return null;
    if (typeof item.note !== "string" || item.note.length > 80) return null;
    if (typeof item.createdAt !== "string" || item.createdAt.length > 40) return null;
    if (txIds.has(item.id)) return null;
    let envelopeId: string | null = null;
    if (item.kind === "expense") {
      if (typeof item.envelopeId !== "string" || !envelopeIds.has(item.envelopeId)) return null;
      envelopeId = item.envelopeId;
    } else if (item.envelopeId !== null && item.envelopeId !== undefined) {
      return null;
    }
    txIds.add(item.id);
    transactions.push({
      id: item.id,
      kind: item.kind,
      envelopeId,
      amountCents,
      note: item.note,
      date: item.date,
      monthKey: item.monthKey,
      createdAt: item.createdAt,
    });
  }

  const savings: SavingsMove[] = [];
  const savingsIds = new Set<string>();
  for (const item of payload.savings) {
    if (!isRecord(item)) return null;
    if (typeof item.id !== "string" || item.id.length < 1 || item.id.length > 80) return null;
    const amountCents = item.amountCents;
    if (!isCents(amountCents, true) || amountCents === 0) return null;
    if (typeof item.note !== "string" || item.note.length > 120) return null;
    if (item.source !== "close" && item.source !== "manual") return null;
    if (!(item.monthKey === null || (typeof item.monthKey === "string" && MONTH.test(item.monthKey)))) {
      return null;
    }
    if (typeof item.createdAt !== "string" || item.createdAt.length > 40) return null;
    if (savingsIds.has(item.id)) return null;
    savingsIds.add(item.id);
    savings.push({
      id: item.id,
      amountCents,
      note: item.note,
      monthKey: item.monthKey,
      source: item.source,
      createdAt: item.createdAt,
    });
  }

  const closedMonths: string[] = [];
  const seenMonths = new Set<string>();
  for (const item of payload.closedMonths) {
    if (typeof item !== "string" || !MONTH.test(item) || seenMonths.has(item)) return null;
    seenMonths.add(item);
    closedMonths.push(item);
  }

  return { envelopes, allocations, transactions, savings, closedMonths };
}

export function serializeBackup(data: BudgetData) {
  return JSON.stringify({ app: "sobres", version: 1, data }, null, 2);
}
