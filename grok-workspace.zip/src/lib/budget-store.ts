import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  addSavings as addSavingsMove,
  addTransaction,
  applyClose,
  applyReopen,
  deleteEnvelope as deleteEnvelopeData,
  emptyData,
  parseBackup,
  removeTransaction as removeTransactionData,
  saveEnvelope as saveEnvelopeData,
  setArchived as setArchivedData,
  type BudgetData,
} from "@/lib/budget-math";

type ExpenseInput = {
  envelopeId: string;
  amountCents: number;
  note: string;
  date: string;
};

type IncomeInput = {
  amountCents: number;
  note: string;
  date: string;
};

type EnvelopeInput = {
  id?: string;
  name: string;
  amountCents: number;
  monthKey: string;
};

type BudgetActions = {
  addIncome: (input: IncomeInput) => string | null;
  addExpense: (input: ExpenseInput) => string | null;
  removeTransaction: (id: string) => string | null;
  saveEnvelope: (input: EnvelopeInput) => string | null;
  setArchived: (id: string, archived: boolean) => string | null;
  deleteEnvelope: (id: string) => string | null;
  closeMonth: (monthKey: string, includeUnassigned: boolean) => string | null;
  reopenMonth: (monthKey: string) => string | null;
  moveSavings: (amountCents: number, note: string) => string | null;
  importBackup: (raw: unknown) => string | null;
  reset: () => void;
};

export type BudgetState = BudgetData & BudgetActions;

function snapshot(state: BudgetState): BudgetData {
  return {
    envelopes: state.envelopes,
    allocations: state.allocations,
    transactions: state.transactions,
    savings: state.savings,
    closedMonths: state.closedMonths,
  };
}

function stamp() {
  return { id: crypto.randomUUID(), now: new Date().toISOString() };
}

export const useBudget = create<BudgetState>()(
  persist(
    (set, get) => {
      const commit = (result: { ok: true; data: BudgetData } | { ok: false; error: string }) => {
        if (!result.ok) return result.error;
        set(result.data);
        return null;
      };
      return {
        ...emptyData,
        addIncome: (input) => {
          const { id, now } = stamp();
          return commit(
            addTransaction(snapshot(get()), {
              kind: "income",
              amountCents: input.amountCents,
              note: input.note,
              date: input.date,
              id,
              now,
            }),
          );
        },
        addExpense: (input) => {
          const { id, now } = stamp();
          return commit(
            addTransaction(snapshot(get()), {
              kind: "expense",
              envelopeId: input.envelopeId,
              amountCents: input.amountCents,
              note: input.note,
              date: input.date,
              id,
              now,
            }),
          );
        },
        removeTransaction: (id) => commit(removeTransactionData(snapshot(get()), id)),
        saveEnvelope: (input) => {
          const { id, now } = stamp();
          return commit(
            saveEnvelopeData(snapshot(get()), {
              ...input,
              idIfNew: id,
              now,
            }),
          );
        },
        setArchived: (id, archived) => commit(setArchivedData(snapshot(get()), id, archived)),
        deleteEnvelope: (id) => commit(deleteEnvelopeData(snapshot(get()), id)),
        closeMonth: (monthKey, includeUnassigned) => {
          const { id, now } = stamp();
          return commit(applyClose(snapshot(get()), monthKey, includeUnassigned, now, id));
        },
        reopenMonth: (monthKey) => commit(applyReopen(snapshot(get()), monthKey)),
        moveSavings: (amountCents, note) => {
          const { id, now } = stamp();
          return commit(addSavingsMove(snapshot(get()), { amountCents, note, id, now }));
        },
        importBackup: (raw) => {
          const data = parseBackup(raw);
          if (!data) return "Ese archivo no es una copia de Sobres.";
          set(data);
          return null;
        },
        reset: () => set(emptyData),
      };
    },
    {
      name: "sobres.v1",
      version: 1,
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined"
          ? { getItem: () => null, setItem: () => undefined, removeItem: () => undefined }
          : localStorage,
      ),
      partialize: (state) => ({
        envelopes: state.envelopes,
        allocations: state.allocations,
        transactions: state.transactions,
        savings: state.savings,
        closedMonths: state.closedMonths,
      }),
    },
  ),
);
