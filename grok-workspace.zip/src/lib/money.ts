export const MAX_CENTS = 1_000_000_000;

export function monthKeyFromDate(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}

export function todayISO(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function shiftMonth(monthKey: string, delta: number) {
  const [year, month] = monthKey.split("-").map(Number);
  return monthKeyFromDate(new Date(year, month - 1 + delta, 1));
}

export function monthBounds(monthKey: string) {
  const [year, month] = monthKey.split("-").map(Number);
  const last = new Date(year, month, 0).getDate();
  return {
    min: `${monthKey}-01`,
    max: `${monthKey}-${String(last).padStart(2, "0")}`,
  };
}

export function defaultDateFor(monthKey: string, today = new Date()) {
  const current = monthKeyFromDate(today);
  const bounds = monthBounds(monthKey);
  if (monthKey === current) return todayISO(today);
  if (monthKey < current) return bounds.max;
  return bounds.min;
}

export function monthLabel(monthKey: string) {
  const [year, month] = monthKey.split("-").map(Number);
  const formatted = new Intl.DateTimeFormat("es", {
    month: "long",
    year: "numeric",
  }).format(new Date(year, month - 1, 1));
  return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}

export function formatDay(isoDate: string) {
  const [year, month, day] = isoDate.split("-").map(Number);
  return new Intl.DateTimeFormat("es", { day: "numeric", month: "short" }).format(
    new Date(year, month - 1, day),
  );
}

export function formatStamp(iso: string) {
  return new Intl.DateTimeFormat("es", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(new Date(iso));
}

export function formatMoney(cents: number) {
  const negative = cents < 0;
  const abs = Math.abs(cents);
  const amount = new Intl.NumberFormat("es-MX", {
    minimumFractionDigits: abs % 100 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(abs / 100);
  return `${negative ? "−" : ""}$${amount}`;
}

export function centsToInput(cents: number) {
  if (cents % 100 === 0) return String(cents / 100);
  return (cents / 100).toFixed(2);
}

export function parseAmountToCents(raw: string): number | null {
  const trimmed = raw.trim().replace(/\s/g, "").replace(/\$/g, "");
  if (!trimmed) return null;
  let normalized = trimmed;
  if (trimmed.includes(",") && trimmed.includes(".")) {
    if (trimmed.lastIndexOf(",") > trimmed.lastIndexOf(".")) {
      normalized = trimmed.replace(/\./g, "").replace(",", ".");
    } else {
      normalized = trimmed.replace(/,/g, "");
    }
  } else if (trimmed.includes(",")) {
    normalized = trimmed.replace(",", ".");
  }
  if (!/^\d+(\.\d{1,2})?$/.test(normalized)) return null;
  const value = Number(normalized);
  if (!Number.isFinite(value) || value < 0) return null;
  const cents = Math.round(value * 100);
  if (cents > MAX_CENTS) return null;
  return cents;
}
