import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  addTransaction,
  applyClose,
  applyReopen,
  closePreview,
  effectiveAllocation,
  emptyData,
  envelopeLeftCents,
  saveEnvelope,
  savingsBalance,
  unassignedCents,
} from "./budget-math.ts";

const NOW = "2026-10-31T12:00:00.000Z";

function book() {
  let data = emptyData;
  const created = saveEnvelope(data, {
    name: "Alimentación",
    amountCents: 8000,
    monthKey: "2026-10",
    idIfNew: "food",
    now: NOW,
  });
  assert.equal(created.ok, true);
  if (!created.ok) return data;
  data = created.data;
  const income = addTransaction(data, {
    kind: "income",
    amountCents: 20000,
    note: "Nómina",
    date: "2026-10-01",
    id: "pay",
    now: NOW,
  });
  assert.equal(income.ok, true);
  if (!income.ok) return data;
  data = income.data;
  const expense = addTransaction(data, {
    kind: "expense",
    envelopeId: "food",
    amountCents: 1800,
    note: "Mercado",
    date: "2026-10-03",
    id: "shop",
    now: NOW,
  });
  assert.equal(expense.ok, true);
  if (!expense.ok) return data;
  return expense.data;
}

describe("sobres", () => {
  it("descuenta el gasto del sobre y deja el resto para ahorro", () => {
    const data = book();
    assert.equal(envelopeLeftCents(data, "2026-10", "food"), 6200);
    assert.equal(unassignedCents(data, "2026-10"), 12000);
    const onlyEnvelopes = closePreview(data, "2026-10", false);
    assert.equal(onlyEnvelopes.envelopeSavingsCents, 6200);
    assert.equal(onlyEnvelopes.totalCents, 6200);
    const withLoose = closePreview(data, "2026-10", true);
    assert.equal(withLoose.totalCents, 18200);
  });

  it("no manda a ahorro un sobre gastado de más", () => {
    let data = book();
    const over = addTransaction(data, {
      kind: "expense",
      envelopeId: "food",
      amountCents: 9000,
      note: "Extra",
      date: "2026-10-04",
      id: "extra",
      now: NOW,
    });
    assert.equal(over.ok, true);
    if (!over.ok) return;
    data = over.data;
    assert.equal(envelopeLeftCents(data, "2026-10", "food"), -2800);
    assert.equal(closePreview(data, "2026-10", false).totalCents, 0);
  });

  it("repite el monto del mes anterior hasta que lo cambias", () => {
    const data = book();
    assert.equal(effectiveAllocation(data, "2026-11", "food"), 8000);
  });

  it("al cerrar pasa el sobrante a ahorro y al reabrir lo revierte", () => {
    const data = book();
    const closed = applyClose(data, "2026-10", false, NOW, "close-1");
    assert.equal(closed.ok, true);
    if (!closed.ok) return;
    assert.equal(savingsBalance(closed.data), 6200);
    assert.equal(closed.data.closedMonths.includes("2026-10"), true);
    const blocked = addTransaction(closed.data, {
      kind: "expense",
      envelopeId: "food",
      amountCents: 100,
      note: "Tarde",
      date: "2026-10-20",
      id: "late",
      now: NOW,
    });
    assert.equal(blocked.ok, false);
    const reopened = applyReopen(closed.data, "2026-10");
    assert.equal(reopened.ok, true);
    if (!reopened.ok) return;
    assert.equal(savingsBalance(reopened.data), 0);
    assert.equal(reopened.data.closedMonths.includes("2026-10"), false);
  });
});
